/* ==========================================
   PHONESTORE - Shared JavaScript
   ========================================== */

const API = 'http://localhost:8080/api';

/* === HELPERS === */
const fmt = (n) => new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(n);
const $ = (s, ctx = document) => ctx.querySelector(s);
const $$ = (s, ctx = document) => [...ctx.querySelectorAll(s)];
const el = (tag, cls = '', html = '') => { const e = document.createElement(tag); if (cls) e.className = cls; if (html) e.innerHTML = html; return e; };

/* === API === */
const api = {
  get: (url) => fetch(API + url).then(r => r.json()),
  post: (url, data) => fetch(API + url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }).then(r => r.json()),
  put: (url, data) => fetch(API + url, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }).then(r => r.json()),
  delete: (url) => fetch(API + url, { method: 'DELETE' }),
};

/* === AUTH === */
const auth = {
  getUser: () => { try { return JSON.parse(localStorage.getItem('user')); } catch { return null; } },
  setUser: (u) => localStorage.setItem('user', JSON.stringify(u)),
  clear: () => { localStorage.removeItem('user'); },
  isLoggedIn: () => !!auth.getUser(),
  isAdmin: () => { const u = auth.getUser(); return u && u.role === 'ROLE_ADMIN'; },
};

/* === CART === */
const cart = {
  get: () => { try { return JSON.parse(localStorage.getItem('cart')) || []; } catch { return []; } },
  set: (items) => { localStorage.setItem('cart', JSON.stringify(items)); cart.updateBadge(); },
  add: (product, qty = 1) => {
    const items = cart.get();
    const productKey = product.variantKey || String(product.id);
    const existing = items.find(i => (i.variantKey || String(i.id)) === productKey);
    const maxStock = product.stock || product.quantity || 99;
    if (existing) {
      existing.qty = Math.min(existing.qty + qty, maxStock);
    } else {
      items.push({
        id: product.id,
        variantKey: product.variantKey || String(product.id),
        name: product.name,
        variantText: product.variantText || '',
        price: product.price,
        imageUrl: product.imageUrl,
        categoryName: product.categoryName,
        qty: qty,
        stock: maxStock
      });
    }
    cart.set(items);
    toast.success(`Đã thêm "${product.name}${product.variantText ? ' (' + product.variantText + ')' : ''}" vào giỏ hàng!`);
  },
  remove: (key) => {
    cart.set(cart.get().filter(i => (i.variantKey || String(i.id)) != String(key) && String(i.id) != String(key)));
  },
  updateQty: (key, qty) => {
    const items = cart.get();
    const item = items.find(i => (i.variantKey || String(i.id)) == String(key) || String(i.id) == String(key));
    if (item) {
      if (qty <= 0) {
        cart.remove(key);
        return;
      }
      item.qty = Math.min(qty, item.stock || 99);
    }
    cart.set(items);
  },
  clear: () => cart.set([]),
  count: () => cart.get().reduce((s, i) => s + i.qty, 0),
  total: () => cart.get().reduce((s, i) => s + i.price * i.qty, 0),
  updateBadge: () => {
    const badges = $$('.cart-badge');
    const count = cart.count();
    badges.forEach(b => { b.textContent = count; b.style.display = count > 0 ? '' : 'none'; });
  },
};

/* === TOAST === */
const toast = {
  _container: null,
  _getContainer: () => {
    if (!toast._container) {
      toast._container = el('div', 'toast-container');
      document.body.appendChild(toast._container);
    }
    return toast._container;
  },
  show: (msg, type = 'info') => {
    const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
    const t = el('div', `toast toast-${type}`);
    t.innerHTML = `<span class="toast-icon">${icons[type]}</span><span>${msg}</span>`;
    toast._getContainer().appendChild(t);
    setTimeout(() => t.remove(), 3400);
  },
  success: (msg) => toast.show(msg, 'success'),
  error: (msg) => toast.show(msg, 'error'),
  info: (msg) => toast.show(msg, 'info'),
};

/* === NAVBAR === */
function initNavbar() {
  // Scrolled class
  window.addEventListener('scroll', () => {
    const nb = $('.navbar');
    if (nb) nb.classList.toggle('scrolled', window.scrollY > 20);
  });

  // Cart badge
  cart.updateBadge();

  // User menu
  const user = auth.getUser();
  const loginBtns = $$('[data-login-btn]');
  const userMenus = $$('[data-user-menu]');

  loginBtns.forEach(btn => {
    btn.style.display = user ? 'none' : '';
  });
  userMenus.forEach(menu => {
    menu.style.display = user ? 'inline-flex' : 'none';
    const nameEl = menu.querySelector('[data-user-name]');
    if (nameEl && user) nameEl.textContent = user.fullName || user.username;

    // Nút chuyển sang trang Admin nếu có quyền ADMIN
    let adminBtn = menu.querySelector('.nav-admin-btn');
    if (user && user.role === 'ROLE_ADMIN') {
      if (!adminBtn) {
        adminBtn = document.createElement('a');
        adminBtn.className = 'nav-admin-btn';
        adminBtn.href = 'admin.html';
        adminBtn.innerHTML = '⚙️ Quản trị';
        const logoutBtn = menu.querySelector('button');
        if (logoutBtn) menu.insertBefore(adminBtn, logoutBtn);
        else menu.appendChild(adminBtn);
      }
      adminBtn.style.display = 'inline-flex';
    } else if (adminBtn) {
      adminBtn.style.display = 'none';
    }
  });

  // Active nav link
  const path = window.location.pathname;
  $$('.nav-link').forEach(link => {
    const href = link.getAttribute('href') || '';
    if (href && path.includes(href.replace('.html', ''))) link.classList.add('active');
  });

  // Hamburger
  const hamburger = $('.hamburger');
  const mobileNav = $('.mobile-nav');
  if (hamburger && mobileNav) {
    hamburger.addEventListener('click', () => mobileNav.classList.toggle('open'));
    const closeBtn = $('.mobile-nav-close');
    if (closeBtn) closeBtn.addEventListener('click', () => mobileNav.classList.remove('open'));
  }

  // Search
  const searchInputs = $$('.navbar-search input, #mobile-search');
  searchInputs.forEach(inp => {
    inp.addEventListener('keydown', e => {
      if (e.key === 'Enter') {
        const q = inp.value.trim();
        const path = window.location.pathname;
        const isIndex = path.endsWith('index.html') || path.endsWith('/') || path === '';
        if (!isIndex && q) {
          window.location.href = `index.html?search=${encodeURIComponent(q)}`;
        }
      }
    });
  });
}

/* === LOGOUT === */
function logout() {
  auth.clear();
  toast.success('Đã đăng xuất!');
  setTimeout(() => window.location.href = 'index.html', 800);
}

/* === PRODUCT CARD TEMPLATE === */
function productCard(p) {
  const stockBadge = p.quantity === 0 ? '<span class="product-card-badge badge-sold-out">Hết hàng</span>' :
                     p.quantity < 5 ? '<span class="product-card-badge badge-hot">🔥 Sắp hết</span>' :
                     p.price < 5000000 ? '<span class="product-card-badge badge-sale">⚡ Giá sốc</span>' :
                     '<span class="product-card-badge badge-new">✨ Mới</span>';

  const details = typeof getPhoneDetails === 'function' ? getPhoneDetails(p) : null;
  const storages = details?.variants?.storages || [];
  const colors = details?.variants?.colors || [];

  const storagesPreview = storages.length ? `
    <div class="product-card-storages">
      ${storages.map(s => `<span class="storage-tag ${s.default ? 'default' : ''}">${s.size}</span>`).join('')}
    </div>` : '';

  const colorsPreview = colors.length ? `
    <div class="product-card-colors">
      ${colors.slice(0, 5).map(c => `<span class="color-dot" style="background:${c.hex};" title="${c.name}"></span>`).join('')}
      ${colors.length > 5 ? `<span class="color-more">+${colors.length - 5}</span>` : ''}
    </div>` : '';

  // Specs chips (Chip / Screen / Battery)
  let specsPreview = '';
  if (details?.specs) {
    const s = details.specs;
    let chipStr = '';
    if (typeof s.performance?.chip === 'string') chipStr = s.performance.chip;
    else if (typeof s.chip === 'string') chipStr = s.chip;

    let screenStr = '';
    if (typeof s.screen?.size === 'string') screenStr = s.screen.size;
    else if (typeof s.screen === 'string') screenStr = s.screen;

    let batStr = '';
    if (typeof s.battery?.capacity === 'string') batStr = s.battery.capacity;
    else if (typeof s.battery === 'string') batStr = s.battery;

    const chip = chipStr ? chipStr.split('(')[0].replace('Qualcomm ', '').replace('Apple ', '').trim() : '';
    const screen = screenStr ? screenStr.split(',')[0].split('phẳng')[0].trim() : '';
    const bat = batStr ? batStr.split('(')[0].trim() : '';

    const items = [chip, screen, bat].filter(Boolean).slice(0, 2);
    if (items.length) {
      specsPreview = `<div class="product-card-specs-row">${items.map(t => `<span class="spec-mini-pill">${t}</span>`).join('')}</div>`;
    }
  }

  const wl = JSON.parse(localStorage.getItem('wishlist') || '[]');
  const isWish = wl.includes(p.id);

  // Original price calculation
  const oldPrice = p.price > 0 ? Math.round((p.price * 1.12) / 100000) * 100000 : 0;
  const discountPercent = oldPrice > p.price ? Math.round((1 - p.price / oldPrice) * 100) : 0;

  // Stable ratings based on ID
  const fakeRate = (4.7 + ((p.id * 7) % 3) / 10).toFixed(1);
  const fakeSold = 50 + ((p.id * 37) % 450);

  return `
    <article class="product-card fade-in">
      <div class="product-card-img">
        <a href="product-detail.html?id=${p.id}" class="img-link">
          <img src="${p.imageUrl || '/images/placeholder.svg'}" 
               alt="${p.name}" loading="lazy"
               onerror="this.src='/images/placeholder.svg'">
        </a>
        ${stockBadge}
        <span class="product-card-installment">Trả góp 0%</span>
        <button class="product-card-wishlist ${isWish ? 'active' : ''}" onclick="toggleWishlist(${p.id}, this)" title="Yêu thích">${isWish ? '♥' : '♡'}</button>
      </div>
      <div class="product-card-body">
        <div class="product-card-meta-top">
          <span class="product-card-brand">${p.categoryName || 'Smartphone'}</span>
          <span class="product-card-rating">⭐ ${fakeRate} <small>(${fakeSold} đã bán)</small></span>
        </div>
        <a href="product-detail.html?id=${p.id}" class="product-card-name" title="${p.name}">${p.name}</a>
        ${specsPreview}
        ${storagesPreview}
        ${colorsPreview}
        
        <div class="product-card-price-area">
          <div class="price-main">${fmt(p.price)}</div>
          ${oldPrice > p.price ? `
            <div class="price-sub-row">
              <span class="price-old">${fmt(oldPrice)}</span>
              <span class="price-discount">-${discountPercent}%</span>
            </div>` : ''}
        </div>

        <div class="product-stock-status ${p.quantity === 0 ? 'out' : p.quantity < 5 ? 'low' : 'in'}">
          <span class="stock-dot"></span>
          <span>${p.quantity === 0 ? 'Tạm hết hàng' : p.quantity < 5 ? 'Chỉ còn ' + p.quantity + ' máy' : 'Sẵn hàng tại shop'}</span>
        </div>

        <div class="product-card-footer">
          <button class="btn btn-primary btn-sm btn-card-add" onclick="addToCartFromCard(${p.id})" ${p.quantity === 0 ? 'disabled' : ''}>
            🛒 Thêm
          </button>
          <a href="product-detail.html?id=${p.id}" class="btn btn-secondary btn-sm btn-card-detail">
            Xem chi tiết
          </a>
        </div>
      </div>
    </article>`;
}

function addToCartFromCard(p) {
  let item = p;
  if (typeof p === 'number') {
    item = (typeof allProducts !== 'undefined' ? allProducts.find(x => x.id === p) : null);
    if (!item && typeof products !== 'undefined') {
      item = products.find(x => x.id === p);
    }
  }
  if (!item) return;

  const details = typeof getPhoneDetails === 'function' ? getPhoneDetails(item) : null;
  const defStorage = details?.variants?.storages?.find(s => s.default) || details?.variants?.storages?.[0];
  const defColor = details?.variants?.colors?.[0];

  if (defStorage && defColor) {
    cart.add({
      id: item.id,
      name: item.name,
      variantKey: `${item.id}_${defStorage.size}_${defColor.name}`,
      variantText: `${defStorage.size} · ${defColor.name}`,
      price: item.price + (defStorage.offset || 0),
      imageUrl: defColor.img || item.imageUrl,
      categoryName: item.categoryName,
      stock: item.quantity || 99
    });
  } else {
    cart.add(item);
  }
}

function toggleWishlist(id, btn) {
  const wl = JSON.parse(localStorage.getItem('wishlist') || '[]');
  const idx = wl.indexOf(id);
  if (idx >= 0) {
    wl.splice(idx, 1);
    btn.innerHTML = '♡';
    btn.classList.remove('active');
    toast.info('Đã xóa khỏi yêu thích');
  } else {
    wl.push(id);
    btn.innerHTML = '♥';
    btn.classList.add('active');
    toast.success('Đã thêm vào yêu thích!');
  }
  localStorage.setItem('wishlist', JSON.stringify(wl));
}

/* === STATUS LABEL === */
function statusBadge(status) {
  const map = {
    PENDING: ['badge-pending', 'Chờ xử lý'],
    SHIPPED: ['badge-shipped', 'Đang giao'],
    DELIVERED: ['badge-delivered', 'Đã giao'],
    CANCELLED: ['badge-cancelled', 'Đã hủy'],
  };
  const [cls, label] = map[status] || ['badge-pending', status];
  return `<span class="badge ${cls}">● ${label}</span>`;
}

/* === FORMAT DATE === */
function fmtDate(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  return d.toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

/* === MODAL HELPERS === */
function openModal(id) { const m = $(`#${id}`); if (m) m.classList.add('active'); }
function closeModal(id) { const m = $(`#${id}`); if (m) m.classList.remove('active'); }

/* === INIT ON DOM READY === */
document.addEventListener('DOMContentLoaded', () => {
  initNavbar();
});