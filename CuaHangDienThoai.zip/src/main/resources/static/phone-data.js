/* ==========================================================
   PHONE DATA - Biến thể (Variants) & Thông số kỹ thuật (Specs Box)
   Chuẩn hóa theo đúng tiêu chuẩn bán lẻ lẻ điện thoại cao cấp
   ========================================================== */

const PHONE_SPECS_DB = {
  // === APPLE ===
  "iphone 15 pro max": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "256GB", offset: 0, default: true },
        { size: "512GB", offset: 5000000 },
        { size: "1TB", offset: 11000000 }
      ],
      colors: [
        { name: "Titan Tự Nhiên", hex: "#9c978f", img: "/images/products/iphone15_promax.jpg" },
        { name: "Titan Đen", hex: "#2b2b2d", img: "/images/products/iphone15_promax.jpg" },
        { name: "Titan Trắng", hex: "#ededed", img: "/images/products/iphone15_promax.jpg" },
        { name: "Titan Xanh", hex: "#3b4453", img: "/images/products/iphone15_promax.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.7 inch",
        panel: "Super Retina XDR OLED, Dynamic Island",
        resolution: "2796 x 1290 Pixels (460 ppi)",
        refreshRate: "120Hz ProMotion tự thích ứng (1 - 120Hz)"
      },
      performance: {
        chip: "Apple A17 Pro (3nm, 6 nhân CPU, 6 nhân GPU)",
        ram: "8GB LPDDR5",
        storage: "256GB / 512GB / 1TB NVMe"
      },
      camera: {
        main: "48MP f/1.78, chống rung cảm biến Sensor-shift thế hệ 2",
        ultraWide: "12MP f/2.2 góc siêu rộng 120 độ, chụp macro",
        tele: "12MP 5x Telephoto Tetraprism, zoom số lên đến 25x",
        video: "4K 60fps ProRes, Cinematic 4K HDR, Action mode, Spatial Video",
        features: "Photonic Engine, Smart HDR 5, Chụp đêm Night mode, Chân dung thế hệ mới"
      },
      battery: {
        capacity: "4.422 mAh (Xem video lên đến 29 giờ)",
        charging: "27W có dây (50% trong 30 phút), cổng USB-C 3.0 (10Gbps)",
        wireless: "Sạc không dây MagSafe 15W, Qi2 15W"
      },
      osAndConnectivity: {
        os: "iOS 17 (Hỗ trợ Apple Intelligence trên iOS 18)",
        network: "5G Sub-6GHz & mmWave đa băng tần cực nhanh",
        sim: "1 eSIM + 1 Nano SIM vật lý (hoặc 2 eSIM)",
        waterproof: "IP68 (chịu nước sâu 6m trong 30 phút)"
      }
    }
  },

  "iphone 15 pro": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "128GB", offset: -3000000 },
        { size: "256GB", offset: 0, default: true },
        { size: "512GB", offset: 5000000 },
        { size: "1TB", offset: 11000000 }
      ],
      colors: [
        { name: "Titan Tự Nhiên", hex: "#9c978f", img: "/images/products/iphone15_pro.jpg" },
        { name: "Titan Đen", hex: "#2b2b2d", img: "/images/products/iphone15_pro.jpg" },
        { name: "Titan Trắng", hex: "#ededed", img: "/images/products/iphone15_pro.jpg" },
        { name: "Titan Xanh", hex: "#3b4453", img: "/images/products/iphone15_pro.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.1 inch",
        panel: "Super Retina XDR OLED, Dynamic Island",
        resolution: "2556 x 1179 Pixels (460 ppi)",
        refreshRate: "120Hz ProMotion tự thích ứng (1 - 120Hz)"
      },
      performance: {
        chip: "Apple A17 Pro (3nm)",
        ram: "8GB",
        storage: "128GB / 256GB / 512GB / 1TB"
      },
      camera: {
        main: "48MP f/1.78 chống rung Sensor-shift OIS",
        ultraWide: "12MP 120 độ macro",
        tele: "12MP 3x Zoom quang học",
        video: "4K 60fps ProRes, Cinematic 4K",
        features: "Smart HDR 5, Deep Fusion, Chân dung lấy nét sau"
      },
      battery: {
        capacity: "3.274 mAh",
        charging: "27W có dây, USB-C 3.0",
        wireless: "MagSafe 15W, Qi2 15W"
      },
      osAndConnectivity: {
        os: "iOS 17 (Sẵn sàng iOS 18)",
        network: "5G",
        sim: "1 Nano SIM + 1 eSIM",
        waterproof: "IP68"
      }
    }
  },

  "iphone 15": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "128GB", offset: 0, default: true },
        { size: "256GB", offset: 2800000 },
        { size: "512GB", offset: 7000000 }
      ],
      colors: [
        { name: "Hồng Pastel", hex: "#f8d8d8", img: "/images/products/iphone15.jpg" },
        { name: "Xanh Lam", hex: "#d5e4eb", img: "/images/products/iphone15.jpg" },
        { name: "Xanh Lá", hex: "#dbe8d8", img: "/images/products/iphone15.jpg" },
        { name: "Vàng Nhạt", hex: "#faebd7", img: "/images/products/iphone15.jpg" },
        { name: "Đen", hex: "#2b2b2d", img: "/images/products/iphone15.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.1 inch",
        panel: "Super Retina XDR OLED, Dynamic Island",
        resolution: "2556 x 1179 Pixels",
        refreshRate: "60Hz, độ sáng tối đa 2000 nits ngoài trời"
      },
      performance: {
        chip: "Apple A16 Bionic (4nm)",
        ram: "6GB",
        storage: "128GB / 256GB / 512GB"
      },
      camera: {
        main: "48MP f/1.6, chống rung quang học OIS thế hệ mới",
        ultraWide: "12MP góc siêu rộng",
        tele: "Zoom quang học 2x tích hợp trên cảm biến chính",
        video: "4K 60fps, Cinematic 4K, HDR Dolby Vision",
        features: "Chụp ảnh siêu phân giải 24MP & 48MP, Smart HDR 5"
      },
      battery: {
        capacity: "3.349 mAh",
        charging: "20W có dây qua cổng USB-C",
        wireless: "MagSafe 15W, Qi 7.5W"
      },
      osAndConnectivity: {
        os: "iOS 17",
        network: "5G",
        sim: "1 Nano SIM + 1 eSIM",
        waterproof: "IP68"
      }
    }
  },

  // === IPHONE 18 SERIES (TƯƠNG LAI) ===
  "iphone 18 pro max": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "256GB", offset: 0, default: true },
        { size: "512GB", offset: 5000000 },
        { size: "1TB", offset: 11000000 },
        { size: "2TB", offset: 18000000 }
      ],
      colors: [
        { name: "Titan Lượng Tử", hex: "#464d56", img: "/images/products/iphone18_promax.jpg" },
        { name: "Titan Ánh Trăng", hex: "#f0f2f5", img: "/images/products/iphone18_promax.jpg" },
        { name: "Titan Đen Vũ Trụ", hex: "#18191b", img: "/images/products/iphone18_promax.jpg" },
        { name: "Titan Đồng Cổ Điển", hex: "#9b7255", img: "/images/products/iphone18_promax.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.9 inch Tràn Viền 100%",
        panel: "Ultra Retina XDR Micro-LED, Không khiếm khuyết",
        resolution: "3120 x 1440 Pixels (520 ppi)",
        refreshRate: "1 - 144Hz ProMotion 2.0"
      },
      performance: {
        chip: "Apple A20 Bionic (Tiến trình 2nm lượng tử, 64 nhân Neural Engine)",
        ram: "16GB LPDDR5X",
        storage: "256GB / 512GB / 1TB / 2TB"
      },
      camera: {
        main: "50MP Cảm biến 1 inch, khẩu độ biến thiên kép f/1.2 - f/4.0",
        ultraWide: "48MP 125 độ góc siêu rộng tích hợp chống méo ảnh AI",
        tele: "48MP Zoom quang học tiềm vọng 10x - Zoom số 50x",
        video: "8K 60fps ProRes, 4K 120fps Dolby Vision, Quay 3D Spatial Video 8K",
        features: "Apple Quantum AI, Night mode thế hệ 4, Smart HDR 7"
      },
      battery: {
        capacity: "5.100 mAh (Xem video lên đến 36 giờ)",
        charging: "45W sạc nhanh USB-C 4.0 (50% trong 20 phút)",
        wireless: "MagSafe 25W, Sạc ngược không dây 10W"
      },
      osAndConnectivity: {
        os: "iOS 19 (Tích hợp Trí tuệ Nhân tạo Apple Intelligence Toàn năng)",
        network: "6G Ready & 5G Advanced siêu tốc",
        sim: "Dual eSIM (hoặc 1 Nano SIM + eSIM)",
        waterproof: "IP68 (sâu 8m trong 45 phút)"
      }
    }
  },

  "iphone 18 pro": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "256GB", offset: 0, default: true },
        { size: "512GB", offset: 5000000 },
        { size: "1TB", offset: 11000000 }
      ],
      colors: [
        { name: "Titan Lượng Tử", hex: "#464d56", img: "/images/products/iphone18_pro.jpg" },
        { name: "Titan Ánh Trăng", hex: "#f0f2f5", img: "/images/products/iphone18_pro.jpg" },
        { name: "Titan Đen Vũ Trụ", hex: "#18191b", img: "/images/products/iphone18_pro.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.3 inch",
        panel: "Ultra Retina XDR Micro-LED viền siêu mỏng",
        resolution: "2778 x 1284 Pixels",
        refreshRate: "1 - 120Hz ProMotion"
      },
      performance: {
        chip: "Apple A20 Bionic (2nm lượng tử)",
        ram: "12GB",
        storage: "256GB / 512GB / 1TB"
      },
      camera: {
        main: "48MP f/1.4 OIS cảm biến lớn",
        ultraWide: "48MP 120 độ macro",
        tele: "48MP Zoom quang 5x",
        video: "4K 120fps ProRes, Cinematic 4K",
        features: "Quantum Neural ISP, Photonic Engine 3"
      },
      battery: {
        capacity: "4.000 mAh",
        charging: "35W có dây, USB-C",
        wireless: "MagSafe 20W"
      },
      osAndConnectivity: {
        os: "iOS 19",
        network: "5G Advanced",
        sim: "Dual eSIM / Nano SIM",
        waterproof: "IP68"
      }
    }
  },

  // === IPHONE 17 SERIES ===
  "iphone 17 pro max": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "256GB", offset: 0, default: true },
        { size: "512GB", offset: 5000000 },
        { size: "1TB", offset: 11000000 }
      ],
      colors: [
        { name: "Titan Sa Mạc", hex: "#bfa382", img: "/images/products/iphone17_promax.jpg" },
        { name: "Titan Xám Không Gian", hex: "#525254", img: "/images/products/iphone17_promax.jpg" },
        { name: "Titan Băng Trắng", hex: "#f1f1f3", img: "/images/products/iphone17_promax.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.9 inch Nano-texture 3000 nits",
        panel: "Super Retina XDR OLED chống chói",
        resolution: "2868 x 1320 Pixels",
        refreshRate: "120Hz ProMotion"
      },
      performance: {
        chip: "Apple A19 Pro (2nm)",
        ram: "12GB",
        storage: "256GB / 512GB / 1TB"
      },
      camera: {
        main: "48MP f/1.6 thế hệ mới",
        ultraWide: "48MP f/2.0 góc siêu rộng",
        tele: "48MP zoom tiềm vọng 10x",
        video: "4K 120fps ProRes, Spatial 4K",
        features: "Apple Intelligence Pro, Smart HDR 6"
      },
      battery: {
        capacity: "4.850 mAh",
        charging: "40W có dây, USB-C",
        wireless: "MagSafe 25W"
      },
      osAndConnectivity: {
        os: "iOS 19",
        network: "5G",
        sim: "eSIM + Nano SIM",
        waterproof: "IP68"
      }
    }
  },

  "iphone 17 pro": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "128GB", offset: -3000000 },
        { size: "256GB", offset: 0, default: true },
        { size: "512GB", offset: 5000000 }
      ],
      colors: [
        { name: "Titan Sa Mạc", hex: "#bfa382", img: "/images/products/iphone17_pro.jpg" },
        { name: "Titan Đen", hex: "#29292a", img: "/images/products/iphone17_pro.jpg" },
        { name: "Titan Bạc", hex: "#ededee", img: "/images/products/iphone17_pro.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.3 inch",
        panel: "Super Retina XDR OLED viền mỏng",
        resolution: "2622 x 1206 Pixels",
        refreshRate: "120Hz ProMotion"
      },
      performance: {
        chip: "Apple A19 Pro (2nm)",
        ram: "10GB",
        storage: "128GB / 256GB / 512GB"
      },
      camera: {
        main: "48MP OIS",
        ultraWide: "48MP macro",
        tele: "12MP zoom 5x",
        video: "4K 120fps",
        features: "Deep Fusion, Apple Intelligence"
      },
      battery: {
        capacity: "3.750 mAh",
        charging: "30W sạc nhanh",
        wireless: "MagSafe 20W"
      },
      osAndConnectivity: {
        os: "iOS 19",
        network: "5G",
        sim: "eSIM + Nano SIM",
        waterproof: "IP68"
      }
    }
  },

  // === IPHONE 16 SERIES ===
  "iphone 16 pro max": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "256GB", offset: 0, default: true },
        { size: "512GB", offset: 5000000 },
        { size: "1TB", offset: 11000000 }
      ],
      colors: [
        { name: "Titan Sa Mạc (Desert)", hex: "#c3a992", img: "/images/products/iphone16_promax.jpg" },
        { name: "Titan Tự Nhiên", hex: "#9b968f", img: "/images/products/iphone16_promax.jpg" },
        { name: "Titan Trắng", hex: "#f0f0f2", img: "/images/products/iphone16_promax.jpg" },
        { name: "Titan Đen", hex: "#2a2a2b", img: "/images/products/iphone16_promax.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.9 inch viền siêu mỏng",
        panel: "Super Retina XDR OLED, Dynamic Island",
        resolution: "2868 x 1320 Pixels (460 ppi)",
        refreshRate: "120Hz ProMotion thích ứng"
      },
      performance: {
        chip: "Apple A18 Pro (3nm thế hệ 2, 16 nhân Neural Engine)",
        ram: "8GB",
        storage: "256GB / 512GB / 1TB"
      },
      camera: {
        main: "48MP Fusion f/1.78 thế hệ 2, Camera Control cảm ứng lực",
        ultraWide: "48MP f/2.2 góc siêu rộng kiêm chụp macro sắc nét",
        tele: "12MP 5x Telephoto Tetraprism zoom quang",
        video: "4K 120fps Dolby Vision, Audio Mix 4 micro chuẩn phòng thu",
        features: "Apple Intelligence cá nhân hóa, Photographic Styles mới"
      },
      battery: {
        capacity: "4.685 mAh (Pin trâu nhất phân khúc)",
        charging: "30W có dây USB-C 3.0",
        wireless: "MagSafe 25W nhanh hơn"
      },
      osAndConnectivity: {
        os: "iOS 18 (Hỗ trợ tiếng Việt đầy đủ)",
        network: "5G Sub-6GHz & mmWave",
        sim: "1 eSIM + 1 Nano SIM",
        waterproof: "IP68"
      }
    }
  },

  "iphone 16 pro": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "128GB", offset: -3000000 },
        { size: "256GB", offset: 0, default: true },
        { size: "512GB", offset: 5000000 },
        { size: "1TB", offset: 11000000 }
      ],
      colors: [
        { name: "Titan Sa Mạc", hex: "#c3a992", img: "/images/products/iphone16_pro.jpg" },
        { name: "Titan Tự Nhiên", hex: "#9b968f", img: "/images/products/iphone16_pro.jpg" },
        { name: "Titan Trắng", hex: "#f0f0f2", img: "/images/products/iphone16_pro.jpg" },
        { name: "Titan Đen", hex: "#2a2a2b", img: "/images/products/iphone16_pro.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.3 inch",
        panel: "Super Retina XDR OLED viền mỏng",
        resolution: "2622 x 1206 Pixels",
        refreshRate: "120Hz ProMotion"
      },
      performance: {
        chip: "Apple A18 Pro (3nm)",
        ram: "8GB",
        storage: "128GB / 256GB / 512GB / 1TB"
      },
      camera: {
        main: "48MP Fusion OIS",
        ultraWide: "48MP góc siêu rộng",
        tele: "12MP 5x Tetraprism",
        video: "4K 120fps Dolby Vision",
        features: "Camera Control, Apple Intelligence"
      },
      battery: {
        capacity: "3.582 mAh",
        charging: "27W có dây",
        wireless: "MagSafe 25W"
      },
      osAndConnectivity: {
        os: "iOS 18",
        network: "5G",
        sim: "1 Nano SIM + 1 eSIM",
        waterproof: "IP68"
      }
    }
  },

  "iphone 16 plus": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "128GB", offset: 0, default: true },
        { size: "256GB", offset: 3000000 },
        { size: "512GB", offset: 7000000 }
      ],
      colors: [
        { name: "Hồng Pastel", hex: "#ebafba", img: "/images/products/iphone16_plus.jpg" },
        { name: "Xanh Mòng Két", hex: "#a4d3cf", img: "/images/products/iphone16_plus.jpg" },
        { name: "Xanh Lưu Ly", hex: "#95b3d7", img: "/images/products/iphone16_plus.jpg" },
        { name: "Đen", hex: "#242526", img: "/images/products/iphone16_plus.jpg" },
        { name: "Trắng", hex: "#f5f6f8", img: "/images/products/iphone16_plus.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.7 inch",
        panel: "Super Retina XDR OLED, Dynamic Island",
        resolution: "2796 x 1290 Pixels",
        refreshRate: "60Hz"
      },
      performance: {
        chip: "Apple A18 (3nm, Apple Intelligence)",
        ram: "8GB",
        storage: "128GB / 256GB / 512GB"
      },
      camera: {
        main: "48MP Fusion 2x tele quang",
        ultraWide: "12MP góc siêu rộng chụp macro",
        tele: "Chụp 2x chất lượng quang",
        video: "4K 60fps, Spatial Video 3D",
        features: "Camera Control, Action Button"
      },
      battery: {
        capacity: "4.674 mAh",
        charging: "25W sạc nhanh qua USB-C",
        wireless: "MagSafe 25W"
      },
      osAndConnectivity: {
        os: "iOS 18",
        network: "5G",
        sim: "1 Nano SIM + eSIM",
        waterproof: "IP68"
      }
    }
  },

  "iphone 16": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "128GB", offset: 0, default: true },
        { size: "256GB", offset: 3000000 },
        { size: "512GB", offset: 7000000 }
      ],
      colors: [
        { name: "Hồng", hex: "#ebafba", img: "/images/products/iphone16.jpg" },
        { name: "Xanh Mòng Két", hex: "#a4d3cf", img: "/images/products/iphone16.jpg" },
        { name: "Xanh Lưu Ly", hex: "#95b3d7", img: "/images/products/iphone16.jpg" },
        { name: "Đen", hex: "#242526", img: "/images/products/iphone16.jpg" },
        { name: "Trắng", hex: "#f5f6f8", img: "/images/products/iphone16.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.1 inch",
        panel: "Super Retina XDR OLED, Dynamic Island",
        resolution: "2556 x 1179 Pixels",
        refreshRate: "60Hz"
      },
      performance: {
        chip: "Apple A18 (3nm, 16 nhân NPU)",
        ram: "8GB",
        storage: "128GB / 256GB / 512GB"
      },
      camera: {
        main: "48MP Fusion 2x tele",
        ultraWide: "12MP góc rộng",
        tele: "Zoom quang 2x",
        video: "4K 60fps, Spatial Video",
        features: "Camera Control cảm ứng, Nút tác vụ Action Button"
      },
      battery: {
        capacity: "3.561 mAh",
        charging: "25W có dây",
        wireless: "MagSafe 25W"
      },
      osAndConnectivity: {
        os: "iOS 18",
        network: "5G",
        sim: "1 Nano SIM + 1 eSIM",
        waterproof: "IP68"
      }
    }
  },

  // === IPHONE 15 PLUS ===
  "iphone 15 plus": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "128GB", offset: 0, default: true },
        { size: "256GB", offset: 3000000 },
        { size: "512GB", offset: 7000000 }
      ],
      colors: [
        { name: "Hồng", hex: "#fed8df", img: "/images/products/iphone15_plus.jpg" },
        { name: "Vàng", hex: "#f7e5b5", img: "/images/products/iphone15_plus.jpg" },
        { name: "Xanh Lá", hex: "#d5e4d7", img: "/images/products/iphone15_plus.jpg" },
        { name: "Xanh Dương", hex: "#d1dfe9", img: "/images/products/iphone15_plus.jpg" },
        { name: "Đen", hex: "#2c2d30", img: "/images/products/iphone15_plus.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.7 inch",
        panel: "Super Retina XDR OLED, Dynamic Island",
        resolution: "2796 x 1290 Pixels",
        refreshRate: "60Hz"
      },
      performance: {
        chip: "Apple A16 Bionic (4nm)",
        ram: "6GB",
        storage: "128GB / 256GB"
      },
      camera: {
        main: "48MP f/1.6, zoom 2x quang",
        ultraWide: "12MP 120 độ",
        tele: "Không có",
        video: "4K 60fps, Cinematic Mode",
        features: "Dynamic Island, Cổng USB-C"
      },
      battery: {
        capacity: "4.383 mAh",
        charging: "20W có dây USB-C",
        wireless: "MagSafe 15W"
      },
      osAndConnectivity: {
        os: "iOS 17",
        network: "5G",
        sim: "1 Nano SIM + eSIM",
        waterproof: "IP68"
      }
    }
  },

  // === IPHONE 14 PRO & PRO MAX & PLUS ===
  "iphone 14 pro max": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "128GB", offset: -2500000 },
        { size: "256GB", offset: 0, default: true },
        { size: "512GB", offset: 5000000 },
        { size: "1TB", offset: 10000000 }
      ],
      colors: [
        { name: "Tím Đậm (Deep Purple)", hex: "#4b4150", img: "/images/products/iphone14_promax.jpg" },
        { name: "Vàng Gold", hex: "#f3e7ce", img: "/images/products/iphone14_promax.jpg" },
        { name: "Bạc Silver", hex: "#ecebe9", img: "/images/products/iphone14_promax.jpg" },
        { name: "Đen Space Black", hex: "#343336", img: "/images/products/iphone14_promax.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.7 inch",
        panel: "Super Retina XDR OLED, Dynamic Island",
        resolution: "2796 x 1290 Pixels",
        refreshRate: "120Hz ProMotion"
      },
      performance: {
        chip: "Apple A16 Bionic (4nm)",
        ram: "6GB",
        storage: "128GB / 256GB / 512GB / 1TB"
      },
      camera: {
        main: "48MP f/1.78 cảm biến quad-pixel",
        ultraWide: "12MP chụp macro",
        tele: "12MP 3x zoom quang",
        video: "4K 60fps, Action Mode 2.8K",
        features: "Dynamic Island, Always-On display"
      },
      battery: {
        capacity: "4.323 mAh",
        charging: "27W có dây Lightning",
        wireless: "MagSafe 15W"
      },
      osAndConnectivity: {
        os: "iOS 17",
        network: "5G",
        sim: "1 Nano SIM + eSIM",
        waterproof: "IP68"
      }
    }
  },

  "iphone 14 pro": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "128GB", offset: -2000000 },
        { size: "256GB", offset: 0, default: true },
        { size: "512GB", offset: 4500000 }
      ],
      colors: [
        { name: "Tím Đậm", hex: "#4b4150", img: "/images/products/iphone14_pro.jpg" },
        { name: "Vàng Gold", hex: "#f3e7ce", img: "/images/products/iphone14_pro.jpg" },
        { name: "Đen Space Black", hex: "#343336", img: "/images/products/iphone14_pro.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.1 inch",
        panel: "Super Retina XDR OLED, Dynamic Island",
        resolution: "2556 x 1179 Pixels",
        refreshRate: "120Hz ProMotion"
      },
      performance: {
        chip: "Apple A16 Bionic",
        ram: "6GB",
        storage: "128GB / 256GB / 512GB"
      },
      camera: {
        main: "48MP f/1.78 Sensor-shift",
        ultraWide: "12MP góc rộng",
        tele: "12MP 3x",
        video: "4K 60fps, Action mode",
        features: "Dynamic Island, Always-On Display"
      },
      battery: {
        capacity: "3.200 mAh",
        charging: "20W",
        wireless: "MagSafe 15W"
      },
      osAndConnectivity: {
        os: "iOS 17",
        network: "5G",
        sim: "1 Nano SIM + eSIM",
        waterproof: "IP68"
      }
    }
  },

  "iphone 14 plus": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "128GB", offset: 0, default: true },
        { size: "256GB", offset: 2500000 }
      ],
      colors: [
        { name: "Xanh Dương", hex: "#a8c0d6", img: "/images/products/iphone14_plus.jpg" },
        { name: "Tím Nhạt", hex: "#e4d9ed", img: "/images/products/iphone14_plus.jpg" },
        { name: "Ánh Sao", hex: "#f7f5ee", img: "/images/products/iphone14_plus.jpg" },
        { name: "Đen Midnight", hex: "#1d232c", img: "/images/products/iphone14_plus.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.7 inch",
        panel: "Super Retina XDR OLED",
        resolution: "2778 x 1284 Pixels",
        refreshRate: "60Hz"
      },
      performance: {
        chip: "Apple A15 Bionic (5 nhân GPU)",
        ram: "6GB",
        storage: "128GB / 256GB"
      },
      camera: {
        main: "12MP f/1.5 OIS",
        ultraWide: "12MP 120 độ",
        tele: "Không có",
        video: "4K 60fps, Cinematic Mode",
        features: "Pin siêu bền bỉ, màn hình lớn"
      },
      battery: {
        capacity: "4.325 mAh",
        charging: "20W có dây",
        wireless: "MagSafe 15W"
      },
      osAndConnectivity: {
        os: "iOS 17",
        network: "5G",
        sim: "1 Nano SIM + eSIM",
        waterproof: "IP68"
      }
    }
  },

  // === IPHONE 13 SERIES ===
  "iphone 13 pro max": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "128GB", offset: 0, default: true },
        { size: "256GB", offset: 2500000 },
        { size: "512GB", offset: 5500000 }
      ],
      colors: [
        { name: "Xanh Sierra Blue", hex: "#9bb5ce", img: "/images/products/iphone13_promax.jpg" },
        { name: "Xanh Alpine Green", hex: "#526255", img: "/images/products/iphone13_promax.jpg" },
        { name: "Xám Than Chì", hex: "#4e4d4b", img: "/images/products/iphone13_promax.jpg" },
        { name: "Vàng Gold", hex: "#fad7a0", img: "/images/products/iphone13_promax.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.7 inch",
        panel: "Super Retina XDR OLED, ProMotion 120Hz",
        resolution: "2778 x 1284 Pixels",
        refreshRate: "120Hz thích ứng"
      },
      performance: {
        chip: "Apple A15 Bionic (5nm, 5 GPU)",
        ram: "6GB",
        storage: "128GB / 256GB / 512GB"
      },
      camera: {
        main: "12MP f/1.5 cảm biến lớn 1.9µm",
        ultraWide: "12MP chụp macro 2cm",
        tele: "12MP 3x zoom quang học",
        video: "4K 60fps ProRes, Cinematic Mode",
        features: "Pin trâu huyền thoại, màn hình 120Hz mượt mà"
      },
      battery: {
        capacity: "4.352 mAh",
        charging: "27W có dây",
        wireless: "MagSafe 15W"
      },
      osAndConnectivity: {
        os: "iOS 17",
        network: "5G",
        sim: "1 Nano SIM + eSIM",
        waterproof: "IP68"
      }
    }
  },

  "iphone 13": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "128GB", offset: 0, default: true },
        { size: "256GB", offset: 2200000 }
      ],
      colors: [
        { name: "Xanh Dương", hex: "#274257", img: "/images/products/iphone13.jpg" },
        { name: "Hồng Nhạt", hex: "#fae0d8", img: "/images/products/iphone13.jpg" },
        { name: "Ánh Sao", hex: "#faf6f2", img: "/images/products/iphone13.jpg" },
        { name: "Đen Midnight", hex: "#1f2022", img: "/images/products/iphone13.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.1 inch",
        panel: "Super Retina XDR OLED độ sáng 800 nits",
        resolution: "2532 x 1170 Pixels",
        refreshRate: "60Hz"
      },
      performance: {
        chip: "Apple A15 Bionic",
        ram: "4GB",
        storage: "128GB / 256GB"
      },
      camera: {
        main: "12MP f/1.6 chống rung Sensor-shift",
        ultraWide: "12MP 120 độ",
        tele: "Không có",
        video: "4K 60fps, Cinematic Mode 1080p",
        features: "Cụm camera chéo, pin vượt trội so với iPhone 12"
      },
      battery: {
        capacity: "3.227 mAh",
        charging: "20W có dây",
        wireless: "MagSafe 15W"
      },
      osAndConnectivity: {
        os: "iOS 17",
        network: "5G",
        sim: "1 Nano SIM + eSIM",
        waterproof: "IP68"
      }
    }
  },

  // === IPHONE 12 SERIES ===
  "iphone 12 pro max": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "128GB", offset: 0, default: true },
        { size: "256GB", offset: 2000000 }
      ],
      colors: [
        { name: "Xanh Pacific Blue", hex: "#2b4553", img: "/images/products/iphone12_promax.jpg" },
        { name: "Vàng Gold", hex: "#e7d3b3", img: "/images/products/iphone12_promax.jpg" },
        { name: "Than Chì Graphite", hex: "#444346", img: "/images/products/iphone12_promax.jpg" },
        { name: "Bạc Silver", hex: "#e2e2e4", img: "/images/products/iphone12_promax.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.7 inch",
        panel: "Super Retina XDR OLED",
        resolution: "2778 x 1284 Pixels",
        refreshRate: "60Hz"
      },
      performance: {
        chip: "Apple A14 Bionic (5nm)",
        ram: "6GB",
        storage: "128GB / 256GB"
      },
      camera: {
        main: "12MP f/1.6 Sensor-shift OIS",
        ultraWide: "12MP",
        tele: "12MP 2.5x zoom quang + LiDAR Scanner",
        video: "4K 60fps Dolby Vision HDR",
        features: "Cảm biến LiDAR đo chiều sâu, Night mode chân dung"
      },
      battery: {
        capacity: "3.687 mAh",
        charging: "20W có dây",
        wireless: "MagSafe 15W"
      },
      osAndConnectivity: {
        os: "iOS 17",
        network: "5G",
        sim: "1 Nano SIM + eSIM",
        waterproof: "IP68"
      }
    }
  },

  "iphone 12": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "64GB", offset: -800000 },
        { size: "128GB", offset: 0, default: true }
      ],
      colors: [
        { name: "Xanh Biển (Blue)", hex: "#1a445d", img: "/images/products/iphone12.jpg" },
        { name: "Xanh Lá (Green)", hex: "#d0e2cb", img: "/images/products/iphone12.jpg" },
        { name: "Đỏ Red", hex: "#ba0c2f", img: "/images/products/iphone12.jpg" },
        { name: "Trắng White", hex: "#f3f3f5", img: "/images/products/iphone12.jpg" },
        { name: "Đen Black", hex: "#1f2022", img: "/images/products/iphone12.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.1 inch",
        panel: "Super Retina XDR OLED",
        resolution: "2532 x 1170 Pixels",
        refreshRate: "60Hz"
      },
      performance: {
        chip: "Apple A14 Bionic (5nm)",
        ram: "4GB",
        storage: "64GB / 128GB"
      },
      camera: {
        main: "12MP f/1.6 OIS",
        ultraWide: "12MP",
        tele: "Không có",
        video: "4K 60fps Dolby Vision",
        features: "Thiết kế cạnh phẳng vuông vắn, hỗ trợ MagSafe"
      },
      battery: {
        capacity: "2.815 mAh",
        charging: "20W",
        wireless: "MagSafe 15W"
      },
      osAndConnectivity: {
        os: "iOS 17",
        network: "5G",
        sim: "1 Nano SIM + eSIM",
        waterproof: "IP68"
      }
    }
  },

  // === IPHONE 11 SERIES ===
  "iphone 11 pro max": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "64GB", offset: -1000000 },
        { size: "256GB", offset: 0, default: true }
      ],
      colors: [
        { name: "Xanh Midnight Green", hex: "#4b534b", img: "/images/products/iphone11_promax.jpg" },
        { name: "Xám Space Gray", hex: "#4e4d4b", img: "/images/products/iphone11_promax.jpg" },
        { name: "Vàng Gold", hex: "#fad7a0", img: "/images/products/iphone11_promax.jpg" },
        { name: "Bạc Silver", hex: "#f0f0f2", img: "/images/products/iphone11_promax.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.5 inch",
        panel: "Super Retina XDR OLED",
        resolution: "2688 x 1242 Pixels",
        refreshRate: "60Hz"
      },
      performance: {
        chip: "Apple A13 Bionic (7nm+)",
        ram: "4GB",
        storage: "64GB / 256GB"
      },
      camera: {
        main: "12MP f/1.8 OIS",
        ultraWide: "12MP 120 độ",
        tele: "12MP 2x zoom quang",
        video: "4K 60fps cả 3 camera",
        features: "Chụp đêm Night Mode đầu tiên, khung thép không gỉ"
      },
      battery: {
        capacity: "3.969 mAh (Pin siêu trâu)",
        charging: "18W sạc nhanh",
        wireless: "Qi 7.5W"
      },
      osAndConnectivity: {
        os: "iOS 17",
        network: "4G LTE Advanced",
        sim: "1 Nano SIM + eSIM",
        waterproof: "IP68"
      }
    }
  },

  "iphone 11": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "64GB", offset: -800000 },
        { size: "128GB", offset: 0, default: true }
      ],
      colors: [
        { name: "Tím Pastel (Purple)", hex: "#d1c9df", img: "/images/products/iphone11.jpg" },
        { name: "Xanh Bạc Hà (Green)", hex: "#c7e3d0", img: "/images/products/iphone11.jpg" },
        { name: "Vàng Yellow", hex: "#fee886", img: "/images/products/iphone11.jpg" },
        { name: "Đen Black", hex: "#1f2022", img: "/images/products/iphone11.jpg" },
        { name: "Trắng White", hex: "#f8f9fa", img: "/images/products/iphone11.jpg" },
        { name: "Đỏ Product Red", hex: "#d82434", img: "/images/products/iphone11.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.1 inch",
        panel: "Liquid Retina HD LCD True Tone",
        resolution: "1792 x 828 Pixels",
        refreshRate: "60Hz"
      },
      performance: {
        chip: "Apple A13 Bionic",
        ram: "4GB",
        storage: "64GB / 128GB"
      },
      camera: {
        main: "12MP f/1.8 OIS góc rộng",
        ultraWide: "12MP góc siêu rộng 120 độ",
        tele: "Không có",
        video: "4K 60fps, Slofie camera trước",
        features: "Chiếc điện thoại quốc dân bền bỉ, giá cực tốt"
      },
      battery: {
        capacity: "3.110 mAh",
        charging: "18W có dây",
        wireless: "Qi 7.5W"
      },
      osAndConnectivity: {
        os: "iOS 17",
        network: "4G LTE",
        sim: "1 Nano SIM + eSIM",
        waterproof: "IP68"
      }
    }
  },

  "iphone 14": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "128GB", offset: 0, default: true },
        { size: "256GB", offset: 2500000 },
        { size: "512GB", offset: 6000000 }
      ],
      colors: [
        { name: "Xanh Dương", hex: "#a8c0d6", img: "/images/products/iphone14.jpg" },
        { name: "Tím Nhạt", hex: "#e4d9ed", img: "/images/products/iphone14.jpg" },
        { name: "Ánh Sao (Starlight)", hex: "#f7f5ee", img: "/images/products/iphone14.jpg" },
        { name: "Đen Midnight", hex: "#1d232c", img: "/images/products/iphone14.jpg" },
        { name: "Đỏ Product Red", hex: "#e02835", img: "/images/products/iphone14.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.1 inch",
        panel: "Super Retina XDR OLED",
        resolution: "2532 x 1170 Pixels",
        refreshRate: "60Hz"
      },
      performance: {
        chip: "Apple A15 Bionic (5 nhân GPU)",
        ram: "6GB",
        storage: "128GB / 256GB"
      },
      camera: {
        main: "12MP f/1.5 chống rung Sensor-shift OIS",
        ultraWide: "12MP 120 độ",
        tele: "Không có (Zoom số 5x)",
        video: "4K 60fps, Cinematic Mode 4K 30fps",
        features: "Photonic Engine, Deep Fusion, Night Mode"
      },
      battery: {
        capacity: "3.279 mAh",
        charging: "20W có dây (Lightning)",
        wireless: "MagSafe 15W"
      },
      osAndConnectivity: {
        os: "iOS 17",
        network: "5G",
        sim: "1 Nano SIM + 1 eSIM",
        waterproof: "IP68"
      }
    }
  },

  // === IPHONE 18 SERIES (TƯƠNG LAI) ===
  "iphone 18 pro max": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "256GB", offset: 0, default: true },
        { size: "512GB", offset: 5000000 },
        { size: "1TB", offset: 11000000 },
        { size: "2TB", offset: 18000000 }
      ],
      colors: [
        { name: "Titan Lượng Tử", hex: "#464d56", img: "/images/products/iphone18_promax.jpg" },
        { name: "Titan Ánh Trăng", hex: "#f0f2f5", img: "/images/products/iphone18_promax.jpg" },
        { name: "Titan Đen Vũ Trụ", hex: "#18191b", img: "/images/products/iphone18_promax.jpg" },
        { name: "Titan Đồng Cổ Điển", hex: "#9b7255", img: "/images/products/iphone18_promax.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.9 inch Tràn Viền 100%",
        panel: "Ultra Retina XDR Micro-LED, Không khiếm khuyết",
        resolution: "3120 x 1440 Pixels (520 ppi)",
        refreshRate: "1 - 144Hz ProMotion 2.0"
      },
      performance: {
        chip: "Apple A20 Bionic (Tiến trình 2nm lượng tử, 64 nhân Neural Engine)",
        ram: "16GB LPDDR5X",
        storage: "256GB / 512GB / 1TB / 2TB"
      },
      camera: {
        main: "50MP Cảm biến 1 inch, khẩu độ biến thiên kép f/1.2 - f/4.0",
        ultraWide: "48MP 125 độ góc siêu rộng tích hợp chống méo ảnh AI",
        tele: "48MP Zoom quang học tiềm vọng 10x - Zoom số 50x",
        video: "8K 60fps ProRes, 4K 120fps Dolby Vision, Quay 3D Spatial Video 8K",
        features: "Apple Quantum AI, Night mode thế hệ 4, Smart HDR 7"
      },
      battery: {
        capacity: "5.100 mAh (Xem video lên đến 36 giờ)",
        charging: "45W sạc nhanh USB-C 4.0 (50% trong 20 phút)",
        wireless: "MagSafe 25W, Sạc ngược không dây 10W"
      },
      osAndConnectivity: {
        os: "iOS 19 (Tích hợp Trí tuệ Nhân tạo Apple Intelligence Toàn năng)",
        network: "6G Ready & 5G Advanced siêu tốc",
        sim: "Dual eSIM (hoặc 1 Nano SIM + eSIM)",
        waterproof: "IP68 (sâu 8m trong 45 phút)"
      }
    }
  },

  "iphone 18 pro": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "256GB", offset: 0, default: true },
        { size: "512GB", offset: 5000000 },
        { size: "1TB", offset: 11000000 }
      ],
      colors: [
        { name: "Titan Lượng Tử", hex: "#464d56", img: "/images/products/iphone18_pro.jpg" },
        { name: "Titan Ánh Trăng", hex: "#f0f2f5", img: "/images/products/iphone18_pro.jpg" },
        { name: "Titan Đen Vũ Trụ", hex: "#18191b", img: "/images/products/iphone18_pro.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.3 inch",
        panel: "Ultra Retina XDR Micro-LED viền siêu mỏng",
        resolution: "2778 x 1284 Pixels",
        refreshRate: "1 - 120Hz ProMotion"
      },
      performance: {
        chip: "Apple A20 Bionic (2nm lượng tử)",
        ram: "12GB",
        storage: "256GB / 512GB / 1TB"
      },
      camera: {
        main: "48MP f/1.4 OIS cảm biến lớn",
        ultraWide: "48MP 120 độ macro",
        tele: "48MP Zoom quang 5x",
        video: "4K 120fps ProRes, Cinematic 4K",
        features: "Quantum Neural ISP, Photonic Engine 3"
      },
      battery: {
        capacity: "4.000 mAh",
        charging: "35W có dây, USB-C",
        wireless: "MagSafe 20W"
      },
      osAndConnectivity: {
        os: "iOS 19",
        network: "5G Advanced",
        sim: "Dual eSIM / Nano SIM",
        waterproof: "IP68"
      }
    }
  },

  // === IPHONE 17 SERIES ===
  "iphone 17 pro max": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "256GB", offset: 0, default: true },
        { size: "512GB", offset: 5000000 },
        { size: "1TB", offset: 11000000 }
      ],
      colors: [
        { name: "Titan Sa Mạc", hex: "#bfa382", img: "/images/products/iphone17_promax.jpg" },
        { name: "Titan Xám Không Gian", hex: "#525254", img: "/images/products/iphone17_promax.jpg" },
        { name: "Titan Băng Trắng", hex: "#f1f1f3", img: "/images/products/iphone17_promax.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.9 inch Nano-texture 3000 nits",
        panel: "Super Retina XDR OLED chống chói",
        resolution: "2868 x 1320 Pixels",
        refreshRate: "120Hz ProMotion"
      },
      performance: {
        chip: "Apple A19 Pro (2nm)",
        ram: "12GB",
        storage: "256GB / 512GB / 1TB"
      },
      camera: {
        main: "48MP f/1.6 thế hệ mới",
        ultraWide: "48MP f/2.0 góc siêu rộng",
        tele: "48MP zoom tiềm vọng 10x",
        video: "4K 120fps ProRes, Spatial 4K",
        features: "Apple Intelligence Pro, Smart HDR 6"
      },
      battery: {
        capacity: "4.850 mAh",
        charging: "40W có dây, USB-C",
        wireless: "MagSafe 25W"
      },
      osAndConnectivity: {
        os: "iOS 19",
        network: "5G",
        sim: "eSIM + Nano SIM",
        waterproof: "IP68"
      }
    }
  },

  "iphone 17 pro": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "128GB", offset: -3000000 },
        { size: "256GB", offset: 0, default: true },
        { size: "512GB", offset: 5000000 }
      ],
      colors: [
        { name: "Titan Sa Mạc", hex: "#bfa382", img: "/images/products/iphone17_pro.jpg" },
        { name: "Titan Đen", hex: "#29292a", img: "/images/products/iphone17_pro.jpg" },
        { name: "Titan Bạc", hex: "#ededee", img: "/images/products/iphone17_pro.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.3 inch",
        panel: "Super Retina XDR OLED viền mỏng",
        resolution: "2622 x 1206 Pixels",
        refreshRate: "120Hz ProMotion"
      },
      performance: {
        chip: "Apple A19 Pro (2nm)",
        ram: "10GB",
        storage: "128GB / 256GB / 512GB"
      },
      camera: {
        main: "48MP OIS",
        ultraWide: "48MP macro",
        tele: "12MP zoom 5x",
        video: "4K 120fps",
        features: "Deep Fusion, Apple Intelligence"
      },
      battery: {
        capacity: "3.750 mAh",
        charging: "30W sạc nhanh",
        wireless: "MagSafe 20W"
      },
      osAndConnectivity: {
        os: "iOS 19",
        network: "5G",
        sim: "eSIM + Nano SIM",
        waterproof: "IP68"
      }
    }
  },

  // === IPHONE 16 SERIES ===
  "iphone 16 pro max": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "256GB", offset: 0, default: true },
        { size: "512GB", offset: 5000000 },
        { size: "1TB", offset: 11000000 }
      ],
      colors: [
        { name: "Titan Sa Mạc (Desert)", hex: "#c3a992", img: "/images/products/iphone16_promax.jpg" },
        { name: "Titan Tự Nhiên", hex: "#9b968f", img: "/images/products/iphone16_promax.jpg" },
        { name: "Titan Trắng", hex: "#f0f0f2", img: "/images/products/iphone16_promax.jpg" },
        { name: "Titan Đen", hex: "#2a2a2b", img: "/images/products/iphone16_promax.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.9 inch viền siêu mỏng",
        panel: "Super Retina XDR OLED, Dynamic Island",
        resolution: "2868 x 1320 Pixels (460 ppi)",
        refreshRate: "120Hz ProMotion thích ứng"
      },
      performance: {
        chip: "Apple A18 Pro (3nm thế hệ 2, 16 nhân Neural Engine)",
        ram: "8GB",
        storage: "256GB / 512GB / 1TB"
      },
      camera: {
        main: "48MP Fusion f/1.78 thế hệ 2, Camera Control cảm ứng lực",
        ultraWide: "48MP f/2.2 góc siêu rộng kiêm chụp macro sắc nét",
        tele: "12MP 5x Telephoto Tetraprism zoom quang",
        video: "4K 120fps Dolby Vision, Audio Mix 4 micro chuẩn phòng thu",
        features: "Apple Intelligence cá nhân hóa, Photographic Styles mới"
      },
      battery: {
        capacity: "4.685 mAh (Pin trâu nhất phân khúc)",
        charging: "30W có dây USB-C 3.0",
        wireless: "MagSafe 25W nhanh hơn"
      },
      osAndConnectivity: {
        os: "iOS 18 (Hỗ trợ tiếng Việt đầy đủ)",
        network: "5G Sub-6GHz & mmWave",
        sim: "1 eSIM + 1 Nano SIM",
        waterproof: "IP68"
      }
    }
  },

  "iphone 16 pro": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "128GB", offset: -3000000 },
        { size: "256GB", offset: 0, default: true },
        { size: "512GB", offset: 5000000 },
        { size: "1TB", offset: 11000000 }
      ],
      colors: [
        { name: "Titan Sa Mạc", hex: "#c3a992", img: "/images/products/iphone16_pro.jpg" },
        { name: "Titan Tự Nhiên", hex: "#9b968f", img: "/images/products/iphone16_pro.jpg" },
        { name: "Titan Trắng", hex: "#f0f0f2", img: "/images/products/iphone16_pro.jpg" },
        { name: "Titan Đen", hex: "#2a2a2b", img: "/images/products/iphone16_pro.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.3 inch",
        panel: "Super Retina XDR OLED viền mỏng",
        resolution: "2622 x 1206 Pixels",
        refreshRate: "120Hz ProMotion"
      },
      performance: {
        chip: "Apple A18 Pro (3nm)",
        ram: "8GB",
        storage: "128GB / 256GB / 512GB / 1TB"
      },
      camera: {
        main: "48MP Fusion OIS",
        ultraWide: "48MP góc siêu rộng",
        tele: "12MP 5x Tetraprism",
        video: "4K 120fps Dolby Vision",
        features: "Camera Control, Apple Intelligence"
      },
      battery: {
        capacity: "3.582 mAh",
        charging: "27W có dây",
        wireless: "MagSafe 25W"
      },
      osAndConnectivity: {
        os: "iOS 18",
        network: "5G",
        sim: "1 Nano SIM + 1 eSIM",
        waterproof: "IP68"
      }
    }
  },

  "iphone 16 plus": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "128GB", offset: 0, default: true },
        { size: "256GB", offset: 3000000 },
        { size: "512GB", offset: 7000000 }
      ],
      colors: [
        { name: "Hồng Pastel", hex: "#ebafba", img: "/images/products/iphone16_plus.jpg" },
        { name: "Xanh Mòng Két", hex: "#a4d3cf", img: "/images/products/iphone16_plus.jpg" },
        { name: "Xanh Lưu Ly", hex: "#95b3d7", img: "/images/products/iphone16_plus.jpg" },
        { name: "Đen", hex: "#242526", img: "/images/products/iphone16_plus.jpg" },
        { name: "Trắng", hex: "#f5f6f8", img: "/images/products/iphone16_plus.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.7 inch",
        panel: "Super Retina XDR OLED, Dynamic Island",
        resolution: "2796 x 1290 Pixels",
        refreshRate: "60Hz"
      },
      performance: {
        chip: "Apple A18 (3nm, Apple Intelligence)",
        ram: "8GB",
        storage: "128GB / 256GB / 512GB"
      },
      camera: {
        main: "48MP Fusion 2x tele quang",
        ultraWide: "12MP góc siêu rộng chụp macro",
        tele: "Chụp 2x chất lượng quang",
        video: "4K 60fps, Spatial Video 3D",
        features: "Camera Control, Action Button"
      },
      battery: {
        capacity: "4.674 mAh",
        charging: "25W sạc nhanh qua USB-C",
        wireless: "MagSafe 25W"
      },
      osAndConnectivity: {
        os: "iOS 18",
        network: "5G",
        sim: "1 Nano SIM + eSIM",
        waterproof: "IP68"
      }
    }
  },

  "iphone 16": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "128GB", offset: 0, default: true },
        { size: "256GB", offset: 3000000 },
        { size: "512GB", offset: 7000000 }
      ],
      colors: [
        { name: "Hồng", hex: "#ebafba", img: "/images/products/iphone16.jpg" },
        { name: "Xanh Mòng Két", hex: "#a4d3cf", img: "/images/products/iphone16.jpg" },
        { name: "Xanh Lưu Ly", hex: "#95b3d7", img: "/images/products/iphone16.jpg" },
        { name: "Đen", hex: "#242526", img: "/images/products/iphone16.jpg" },
        { name: "Trắng", hex: "#f5f6f8", img: "/images/products/iphone16.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.1 inch",
        panel: "Super Retina XDR OLED, Dynamic Island",
        resolution: "2556 x 1179 Pixels",
        refreshRate: "60Hz"
      },
      performance: {
        chip: "Apple A18 (3nm, 16 nhân NPU)",
        ram: "8GB",
        storage: "128GB / 256GB / 512GB"
      },
      camera: {
        main: "48MP Fusion 2x tele",
        ultraWide: "12MP góc rộng",
        tele: "Zoom quang 2x",
        video: "4K 60fps, Spatial Video",
        features: "Camera Control cảm ứng, Nút tác vụ Action Button"
      },
      battery: {
        capacity: "3.561 mAh",
        charging: "25W có dây",
        wireless: "MagSafe 25W"
      },
      osAndConnectivity: {
        os: "iOS 18",
        network: "5G",
        sim: "1 Nano SIM + 1 eSIM",
        waterproof: "IP68"
      }
    }
  },

  // === IPHONE 15 PLUS ===
  "iphone 15 plus": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "128GB", offset: 0, default: true },
        { size: "256GB", offset: 3000000 },
        { size: "512GB", offset: 7000000 }
      ],
      colors: [
        { name: "Hồng", hex: "#fed8df", img: "/images/products/iphone15_plus.jpg" },
        { name: "Vàng", hex: "#f7e5b5", img: "/images/products/iphone15_plus.jpg" },
        { name: "Xanh Lá", hex: "#d5e4d7", img: "/images/products/iphone15_plus.jpg" },
        { name: "Xanh Dương", hex: "#d1dfe9", img: "/images/products/iphone15_plus.jpg" },
        { name: "Đen", hex: "#2c2d30", img: "/images/products/iphone15_plus.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.7 inch",
        panel: "Super Retina XDR OLED, Dynamic Island",
        resolution: "2796 x 1290 Pixels",
        refreshRate: "60Hz"
      },
      performance: {
        chip: "Apple A16 Bionic (4nm)",
        ram: "6GB",
        storage: "128GB / 256GB"
      },
      camera: {
        main: "48MP f/1.6, zoom 2x quang",
        ultraWide: "12MP 120 độ",
        tele: "Không có",
        video: "4K 60fps, Cinematic Mode",
        features: "Dynamic Island, Cổng USB-C"
      },
      battery: {
        capacity: "4.383 mAh",
        charging: "20W có dây USB-C",
        wireless: "MagSafe 15W"
      },
      osAndConnectivity: {
        os: "iOS 17",
        network: "5G",
        sim: "1 Nano SIM + eSIM",
        waterproof: "IP68"
      }
    }
  },

  // === IPHONE 14 PRO & PRO MAX & PLUS ===
  "iphone 14 pro max": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "128GB", offset: -2500000 },
        { size: "256GB", offset: 0, default: true },
        { size: "512GB", offset: 5000000 },
        { size: "1TB", offset: 10000000 }
      ],
      colors: [
        { name: "Tím Đậm (Deep Purple)", hex: "#4b4150", img: "/images/products/iphone14_promax.jpg" },
        { name: "Vàng Gold", hex: "#f3e7ce", img: "/images/products/iphone14_promax.jpg" },
        { name: "Bạc Silver", hex: "#ecebe9", img: "/images/products/iphone14_promax.jpg" },
        { name: "Đen Space Black", hex: "#343336", img: "/images/products/iphone14_promax.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.7 inch",
        panel: "Super Retina XDR OLED, Dynamic Island",
        resolution: "2796 x 1290 Pixels",
        refreshRate: "120Hz ProMotion"
      },
      performance: {
        chip: "Apple A16 Bionic (4nm)",
        ram: "6GB",
        storage: "128GB / 256GB / 512GB / 1TB"
      },
      camera: {
        main: "48MP f/1.78 cảm biến quad-pixel",
        ultraWide: "12MP chụp macro",
        tele: "12MP 3x zoom quang",
        video: "4K 60fps, Action Mode 2.8K",
        features: "Dynamic Island, Always-On display"
      },
      battery: {
        capacity: "4.323 mAh",
        charging: "27W có dây Lightning",
        wireless: "MagSafe 15W"
      },
      osAndConnectivity: {
        os: "iOS 17",
        network: "5G",
        sim: "1 Nano SIM + eSIM",
        waterproof: "IP68"
      }
    }
  },

  "iphone 14 pro": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "128GB", offset: -2000000 },
        { size: "256GB", offset: 0, default: true },
        { size: "512GB", offset: 4500000 }
      ],
      colors: [
        { name: "Tím Đậm", hex: "#4b4150", img: "/images/products/iphone14_pro.jpg" },
        { name: "Vàng Gold", hex: "#f3e7ce", img: "/images/products/iphone14_pro.jpg" },
        { name: "Đen Space Black", hex: "#343336", img: "/images/products/iphone14_pro.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.1 inch",
        panel: "Super Retina XDR OLED, Dynamic Island",
        resolution: "2556 x 1179 Pixels",
        refreshRate: "120Hz ProMotion"
      },
      performance: {
        chip: "Apple A16 Bionic",
        ram: "6GB",
        storage: "128GB / 256GB / 512GB"
      },
      camera: {
        main: "48MP f/1.78 Sensor-shift",
        ultraWide: "12MP góc rộng",
        tele: "12MP 3x",
        video: "4K 60fps, Action mode",
        features: "Dynamic Island, Always-On Display"
      },
      battery: {
        capacity: "3.200 mAh",
        charging: "20W",
        wireless: "MagSafe 15W"
      },
      osAndConnectivity: {
        os: "iOS 17",
        network: "5G",
        sim: "1 Nano SIM + eSIM",
        waterproof: "IP68"
      }
    }
  },

  "iphone 14 plus": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "128GB", offset: 0, default: true },
        { size: "256GB", offset: 2500000 }
      ],
      colors: [
        { name: "Xanh Dương", hex: "#a8c0d6", img: "/images/products/iphone14_plus.jpg" },
        { name: "Tím Nhạt", hex: "#e4d9ed", img: "/images/products/iphone14_plus.jpg" },
        { name: "Ánh Sao", hex: "#f7f5ee", img: "/images/products/iphone14_plus.jpg" },
        { name: "Đen Midnight", hex: "#1d232c", img: "/images/products/iphone14_plus.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.7 inch",
        panel: "Super Retina XDR OLED",
        resolution: "2778 x 1284 Pixels",
        refreshRate: "60Hz"
      },
      performance: {
        chip: "Apple A15 Bionic (5 nhân GPU)",
        ram: "6GB",
        storage: "128GB / 256GB"
      },
      camera: {
        main: "12MP f/1.5 OIS",
        ultraWide: "12MP 120 độ",
        tele: "Không có",
        video: "4K 60fps, Cinematic Mode",
        features: "Pin siêu bền bỉ, màn hình lớn"
      },
      battery: {
        capacity: "4.325 mAh",
        charging: "20W có dây",
        wireless: "MagSafe 15W"
      },
      osAndConnectivity: {
        os: "iOS 17",
        network: "5G",
        sim: "1 Nano SIM + eSIM",
        waterproof: "IP68"
      }
    }
  },

  // === IPHONE 13 SERIES ===
  "iphone 13 pro max": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "128GB", offset: 0, default: true },
        { size: "256GB", offset: 2500000 },
        { size: "512GB", offset: 5500000 }
      ],
      colors: [
        { name: "Xanh Sierra Blue", hex: "#9bb5ce", img: "/images/products/iphone13_promax.jpg" },
        { name: "Xanh Alpine Green", hex: "#526255", img: "/images/products/iphone13_promax.jpg" },
        { name: "Xám Than Chì", hex: "#4e4d4b", img: "/images/products/iphone13_promax.jpg" },
        { name: "Vàng Gold", hex: "#fad7a0", img: "/images/products/iphone13_promax.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.7 inch",
        panel: "Super Retina XDR OLED, ProMotion 120Hz",
        resolution: "2778 x 1284 Pixels",
        refreshRate: "120Hz thích ứng"
      },
      performance: {
        chip: "Apple A15 Bionic (5nm, 5 GPU)",
        ram: "6GB",
        storage: "128GB / 256GB / 512GB"
      },
      camera: {
        main: "12MP f/1.5 cảm biến lớn 1.9µm",
        ultraWide: "12MP chụp macro 2cm",
        tele: "12MP 3x zoom quang học",
        video: "4K 60fps ProRes, Cinematic Mode",
        features: "Pin trâu huyền thoại, màn hình 120Hz mượt mà"
      },
      battery: {
        capacity: "4.352 mAh",
        charging: "27W có dây",
        wireless: "MagSafe 15W"
      },
      osAndConnectivity: {
        os: "iOS 17",
        network: "5G",
        sim: "1 Nano SIM + eSIM",
        waterproof: "IP68"
      }
    }
  },

  "iphone 13": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "128GB", offset: 0, default: true },
        { size: "256GB", offset: 2200000 }
      ],
      colors: [
        { name: "Xanh Dương", hex: "#274257", img: "/images/products/iphone13.jpg" },
        { name: "Hồng Nhạt", hex: "#fae0d8", img: "/images/products/iphone13.jpg" },
        { name: "Ánh Sao", hex: "#faf6f2", img: "/images/products/iphone13.jpg" },
        { name: "Đen Midnight", hex: "#1f2022", img: "/images/products/iphone13.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.1 inch",
        panel: "Super Retina XDR OLED độ sáng 800 nits",
        resolution: "2532 x 1170 Pixels",
        refreshRate: "60Hz"
      },
      performance: {
        chip: "Apple A15 Bionic",
        ram: "4GB",
        storage: "128GB / 256GB"
      },
      camera: {
        main: "12MP f/1.6 chống rung Sensor-shift",
        ultraWide: "12MP 120 độ",
        tele: "Không có",
        video: "4K 60fps, Cinematic Mode 1080p",
        features: "Cụm camera chéo, pin vượt trội so với iPhone 12"
      },
      battery: {
        capacity: "3.227 mAh",
        charging: "20W có dây",
        wireless: "MagSafe 15W"
      },
      osAndConnectivity: {
        os: "iOS 17",
        network: "5G",
        sim: "1 Nano SIM + eSIM",
        waterproof: "IP68"
      }
    }
  },

  // === IPHONE 12 SERIES ===
  "iphone 12 pro max": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "128GB", offset: 0, default: true },
        { size: "256GB", offset: 2000000 }
      ],
      colors: [
        { name: "Xanh Pacific Blue", hex: "#2b4553", img: "/images/products/iphone12_promax.jpg" },
        { name: "Vàng Gold", hex: "#e7d3b3", img: "/images/products/iphone12_promax.jpg" },
        { name: "Than Chì Graphite", hex: "#444346", img: "/images/products/iphone12_promax.jpg" },
        { name: "Bạc Silver", hex: "#e2e2e4", img: "/images/products/iphone12_promax.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.7 inch",
        panel: "Super Retina XDR OLED",
        resolution: "2778 x 1284 Pixels",
        refreshRate: "60Hz"
      },
      performance: {
        chip: "Apple A14 Bionic (5nm)",
        ram: "6GB",
        storage: "128GB / 256GB"
      },
      camera: {
        main: "12MP f/1.6 Sensor-shift OIS",
        ultraWide: "12MP",
        tele: "12MP 2.5x zoom quang + LiDAR Scanner",
        video: "4K 60fps Dolby Vision HDR",
        features: "Cảm biến LiDAR đo chiều sâu, Night mode chân dung"
      },
      battery: {
        capacity: "3.687 mAh",
        charging: "20W có dây",
        wireless: "MagSafe 15W"
      },
      osAndConnectivity: {
        os: "iOS 17",
        network: "5G",
        sim: "1 Nano SIM + eSIM",
        waterproof: "IP68"
      }
    }
  },

  "iphone 12": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "64GB", offset: -800000 },
        { size: "128GB", offset: 0, default: true }
      ],
      colors: [
        { name: "Xanh Biển (Blue)", hex: "#1a445d", img: "/images/products/iphone12.jpg" },
        { name: "Xanh Lá (Green)", hex: "#d0e2cb", img: "/images/products/iphone12.jpg" },
        { name: "Đỏ Red", hex: "#ba0c2f", img: "/images/products/iphone12.jpg" },
        { name: "Trắng White", hex: "#f3f3f5", img: "/images/products/iphone12.jpg" },
        { name: "Đen Black", hex: "#1f2022", img: "/images/products/iphone12.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.1 inch",
        panel: "Super Retina XDR OLED",
        resolution: "2532 x 1170 Pixels",
        refreshRate: "60Hz"
      },
      performance: {
        chip: "Apple A14 Bionic (5nm)",
        ram: "4GB",
        storage: "64GB / 128GB"
      },
      camera: {
        main: "12MP f/1.6 OIS",
        ultraWide: "12MP",
        tele: "Không có",
        video: "4K 60fps Dolby Vision",
        features: "Thiết kế cạnh phẳng vuông vắn, hỗ trợ MagSafe"
      },
      battery: {
        capacity: "2.815 mAh",
        charging: "20W",
        wireless: "MagSafe 15W"
      },
      osAndConnectivity: {
        os: "iOS 17",
        network: "5G",
        sim: "1 Nano SIM + eSIM",
        waterproof: "IP68"
      }
    }
  },

  // === IPHONE 11 SERIES ===
  "iphone 11 pro max": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "64GB", offset: -1000000 },
        { size: "256GB", offset: 0, default: true }
      ],
      colors: [
        { name: "Xanh Midnight Green", hex: "#4b534b", img: "/images/products/iphone11_promax.jpg" },
        { name: "Xám Space Gray", hex: "#4e4d4b", img: "/images/products/iphone11_promax.jpg" },
        { name: "Vàng Gold", hex: "#fad7a0", img: "/images/products/iphone11_promax.jpg" },
        { name: "Bạc Silver", hex: "#f0f0f2", img: "/images/products/iphone11_promax.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.5 inch",
        panel: "Super Retina XDR OLED",
        resolution: "2688 x 1242 Pixels",
        refreshRate: "60Hz"
      },
      performance: {
        chip: "Apple A13 Bionic (7nm+)",
        ram: "4GB",
        storage: "64GB / 256GB"
      },
      camera: {
        main: "12MP f/1.8 OIS",
        ultraWide: "12MP 120 độ",
        tele: "12MP 2x zoom quang",
        video: "4K 60fps cả 3 camera",
        features: "Chụp đêm Night Mode đầu tiên, khung thép không gỉ"
      },
      battery: {
        capacity: "3.969 mAh (Pin siêu trâu)",
        charging: "18W sạc nhanh",
        wireless: "Qi 7.5W"
      },
      osAndConnectivity: {
        os: "iOS 17",
        network: "4G LTE Advanced",
        sim: "1 Nano SIM + eSIM",
        waterproof: "IP68"
      }
    }
  },

  "iphone 11": {
    brand: "Apple",
    variants: {
      storages: [
        { size: "64GB", offset: -800000 },
        { size: "128GB", offset: 0, default: true }
      ],
      colors: [
        { name: "Tím Pastel (Purple)", hex: "#d1c9df", img: "/images/products/iphone11.jpg" },
        { name: "Xanh Bạc Hà (Green)", hex: "#c7e3d0", img: "/images/products/iphone11.jpg" },
        { name: "Vàng Yellow", hex: "#fee886", img: "/images/products/iphone11.jpg" },
        { name: "Đen Black", hex: "#1f2022", img: "/images/products/iphone11.jpg" },
        { name: "Trắng White", hex: "#f8f9fa", img: "/images/products/iphone11.jpg" },
        { name: "Đỏ Product Red", hex: "#d82434", img: "/images/products/iphone11.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.1 inch",
        panel: "Liquid Retina HD LCD True Tone",
        resolution: "1792 x 828 Pixels",
        refreshRate: "60Hz"
      },
      performance: {
        chip: "Apple A13 Bionic",
        ram: "4GB",
        storage: "64GB / 128GB"
      },
      camera: {
        main: "12MP f/1.8 OIS góc rộng",
        ultraWide: "12MP góc siêu rộng 120 độ",
        tele: "Không có",
        video: "4K 60fps, Slofie camera trước",
        features: "Chiếc điện thoại quốc dân bền bỉ, giá cực tốt"
      },
      battery: {
        capacity: "3.110 mAh",
        charging: "18W có dây",
        wireless: "Qi 7.5W"
      },
      osAndConnectivity: {
        os: "iOS 17",
        network: "4G LTE",
        sim: "1 Nano SIM + eSIM",
        waterproof: "IP68"
      }
    }
  },

  // === SAMSUNG ===
  "samsung galaxy s24 ultra": {
    brand: "Samsung",
    variants: {
      storages: [
        { size: "256GB", offset: 0, default: true },
        { size: "512GB", offset: 4000000 },
        { size: "1TB", offset: 9000000 }
      ],
      colors: [
        { name: "Xám Titan", hex: "#7a7775", img: "/images/products/s24_ultra.jpg" },
        { name: "Đen Titan", hex: "#2b2a2e", img: "/images/products/s24_ultra.jpg" },
        { name: "Tím Titan", hex: "#59546b", img: "/images/products/s24_ultra.jpg" },
        { name: "Vàng Titan", hex: "#e8dcbe", img: "/images/products/s24_ultra.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.8 inch phẳng hoàn toàn, kính Gorilla Armor chống lóa",
        panel: "Dynamic AMOLED 2X, HDR10+, 2600 nits đỉnh cao",
        resolution: "Quad HD+ (3120 x 1440 Pixels)",
        refreshRate: "120Hz thích ứng LTPO (1 - 120Hz)"
      },
      performance: {
        chip: "Snapdragon 8 Gen 3 for Galaxy (4nm, GPU Adreno 750)",
        ram: "12GB LPDDR5X",
        storage: "256GB / 512GB / 1TB UFS 4.0"
      },
      camera: {
        main: "200MP f/1.7 OIS siêu cảm biến, zoom quang 2x chất lượng cao",
        ultraWide: "12MP f/2.2 góc 120 độ Dual Pixel AF",
        tele: "50MP 5x Periscope Zoom quang 10x quang học, 100x Space Zoom",
        video: "8K 30fps, 4K 120fps quay phim slow-mo mượt mà",
        features: "Galaxy AI chỉnh sửa ảnh thông minh, Nightography zoom đêm, OIS kép"
      },
      battery: {
        capacity: "5.000 mAh (Xem video lên tới 30 giờ)",
        charging: "45W Super Fast Charging 2.0 (65% trong 30 phút)",
        wireless: "Fast Wireless Charging 15W, sạc ngược không dây Wireless PowerShare 4.5W"
      },
      osAndConnectivity: {
        os: "Android 14, One UI 6.1 tích hợp trọn bộ Galaxy AI (Cam kết 7 năm cập nhật OS)",
        network: "5G kép, Wi-Fi 7, Bluetooth 5.3, UWB",
        sim: "2 Nano SIM vật lý + eSIM",
        waterproof: "IP68 kèm bút S-Pen tích hợp có Bluetooth"
      }
    }
  },

  "samsung galaxy s24+": {
    brand: "Samsung",
    variants: {
      storages: [
        { size: "256GB", offset: 0, default: true },
        { size: "512GB", offset: 3500000 }
      ],
      colors: [
        { name: "Đen Onyx", hex: "#2b2a2e", img: "/images/products/s24_plus.jpg" },
        { name: "Xám Marble", hex: "#a4a3a8", img: "/images/products/s24_plus.jpg" },
        { name: "Tím Cobalt", hex: "#5b5570", img: "/images/products/s24_plus.jpg" },
        { name: "Vàng Amber", hex: "#e8dcbe", img: "/images/products/s24_plus.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.7 inch",
        panel: "Dynamic AMOLED 2X, 2600 nits",
        resolution: "Quad HD+ (3120 x 1440)",
        refreshRate: "120Hz LTPO thích ứng"
      },
      performance: {
        chip: "Exynos 2400 10 nhân (hoặc Snapdragon 8 Gen 3)",
        ram: "12GB",
        storage: "256GB / 512GB"
      },
      camera: {
        main: "50MP f/1.8 Dual Pixel OIS",
        ultraWide: "12MP 120 độ",
        tele: "10MP 3x Zoom quang học OIS, 30x kỹ thuật số",
        video: "8K 30fps, 4K 60fps",
        features: "Galaxy AI, Zoom ban đêm, Super HDR"
      },
      battery: {
        capacity: "4.900 mAh",
        charging: "45W sạc nhanh",
        wireless: "Sạc không dây 15W, chia sẻ pin"
      },
      osAndConnectivity: {
        os: "Android 14, One UI 6.1 (7 năm cập nhật)",
        network: "5G",
        sim: "2 SIM vật lý + eSIM",
        waterproof: "IP68"
      }
    }
  },

  "samsung galaxy z fold6": {
    brand: "Samsung",
    variants: {
      storages: [
        { size: "256GB", offset: 0, default: true },
        { size: "512GB", offset: 4500000 },
        { size: "1TB", offset: 10000000 }
      ],
      colors: [
        { name: "Xám Metal", hex: "#7a818c", img: "/images/products/z_fold6.jpg" },
        { name: "Hồng Rosé", hex: "#f1d6d6", img: "/images/products/z_fold6.jpg" },
        { name: "Xanh Navy", hex: "#1c2c40", img: "/images/products/z_fold6.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "Màn hình gập chính 7.6 inch, màn hình phụ 6.3 inch",
        panel: "Dynamic AMOLED 2X gập dẻo siêu mỏng, 2600 nits",
        resolution: "Chính: QXGA+ (2160 x 1856), Phụ: HD+ (2376 x 968)",
        refreshRate: "120Hz cả 2 màn hình"
      },
      performance: {
        chip: "Snapdragon 8 Gen 3 for Galaxy",
        ram: "12GB LPDDR5X",
        storage: "256GB / 512GB / 1TB"
      },
      camera: {
        main: "50MP OIS Dual Pixel",
        ultraWide: "12MP 120 độ",
        tele: "10MP 3x Zoom quang OIS, 30x Space Zoom",
        video: "8K 30fps, 4K 60fps",
        features: "FlexCam góc gập linh hoạt, Galaxy AI Sketch to Image"
      },
      battery: {
        capacity: "4.400 mAh",
        charging: "25W sạc có dây",
        wireless: "15W không dây, sạc ngược"
      },
      osAndConnectivity: {
        os: "Android 14, One UI 6.1.1 tối ưu đa nhiệm",
        network: "5G kép, Wi-Fi 7",
        sim: "2 SIM Nano + eSIM",
        waterproof: "IP48 chuẩn kháng nước kháng bụi màn gập"
      }
    }
  },

  "samsung galaxy a55 5g": {
    brand: "Samsung",
    variants: {
      storages: [
        { size: "128GB", offset: 0, default: true },
        { size: "256GB", offset: 1200000 }
      ],
      colors: [
        { name: "Xanh Iceblue", hex: "#cde3f7", img: "/images/products/galaxy_a55.jpg" },
        { name: "Tím Lilac", hex: "#ded4ea", img: "/images/products/galaxy_a55.jpg" },
        { name: "Xanh Navy", hex: "#1f2a3a", img: "/images/products/galaxy_a55.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.6 inch viền kim loại sang trọng",
        panel: "Super AMOLED, FHD+, 1000 nits Vision Booster",
        resolution: "1080 x 2340 Pixels",
        refreshRate: "120Hz mượt mà"
      },
      performance: {
        chip: "Exynos 1480 (4nm, GPU AMD Xclipse 530 gaming)",
        ram: "8GB",
        storage: "128GB / 256GB (hỗ trợ thẻ MicroSD 1TB)"
      },
      camera: {
        main: "50MP f/1.8 OIS chống rung quang học sắc nét",
        ultraWide: "12MP góc rộng 123 độ",
        tele: "5MP Macro chụp cận cảnh chi tiết",
        video: "4K 30fps, VDIS chống rung video",
        features: "Chụp đêm Nightography, AI Image Signal Processing"
      },
      battery: {
        capacity: "5.000 mAh (dùng đến 2 ngày)",
        charging: "25W sạc nhanh",
        wireless: "Không hỗ trợ"
      },
      osAndConnectivity: {
        os: "Android 14, One UI 6.1 (4 lần nâng cấp OS)",
        network: "5G Sub6",
        sim: "2 Nano SIM (SIM 2 chung khe thẻ nhớ)",
        waterproof: "IP67 kháng nước kháng bụi chuẩn cao"
      }
    }
  },

  // === XIAOMI ===
  "xiaomi 14 ultra": {
    brand: "Xiaomi",
    variants: {
      storages: [
        { size: "256GB", offset: 0 },
        { size: "512GB", offset: 2500000, default: true },
        { size: "1TB", offset: 6000000 }
      ],
      colors: [
        { name: "Đen Da Sinh Học", hex: "#222222", img: "/images/products/xiaomi14_ultra.jpg" },
        { name: "Trắng Gốm", hex: "#f0f0f0", img: "/images/products/xiaomi14_ultra.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.73 inch cong nhẹ 4 cạnh All Around Liquid Display",
        panel: "LTPO AMOLED, 68 tỷ màu, Dolby Vision, 3000 nits",
        resolution: "WQHD+ (3200 x 1440 Pixels, 522 ppi)",
        refreshRate: "120Hz thích ứng (1 - 120Hz)"
      },
      performance: {
        chip: "Snapdragon 8 Gen 3 (4nm) tản nhiệt buồng hơi vòng đôi",
        ram: "16GB LPDDR5X",
        storage: "512GB UFS 4.0"
      },
      camera: {
        main: "50MP cảm biến 1-inch Sony LYT-900, khẩu độ biến thiên vô cấp f/1.63 - f/4.0 OIS",
        ultraWide: "50MP Leica 122 độ macro 5cm",
        tele: "50MP 3.2x Tele + 50MP 5x Periscope kính tiềm vọng Leica",
        video: "8K 30fps toàn bộ 4 ống kính, 4K 120fps, 10-bit Log",
        features: "Hệ thấu kính quang học Leica Summilux, Master Portrait"
      },
      battery: {
        capacity: "5.000 mAh",
        charging: "90W HyperCharge có dây (100% trong 33 phút)",
        wireless: "80W sạc không dây siêu nhanh, sạc ngược 10W"
      },
      osAndConnectivity: {
        os: "Xiaomi HyperOS trên nền Android 14",
        network: "5G kép chuẩn Wi-Fi 7",
        sim: "2 Nano SIM vật lý",
        waterproof: "IP68 kháng nước bụi tuyệt đối"
      }
    }
  },

  "redmi note 13 pro+": {
    brand: "Xiaomi",
    variants: {
      storages: [
        { size: "256GB", offset: 0, default: true },
        { size: "512GB", offset: 1500000 }
      ],
      colors: [
        { name: "Tím Pastel Aurora", hex: "#cdc4e8", img: "/images/products/redmi_note13.jpg" },
        { name: "Đen Bán Dạ", hex: "#1d2120", img: "/images/products/redmi_note13.jpg" },
        { name: "Trắng Ánh Trăng", hex: "#f0f2f5", img: "/images/products/redmi_note13.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.67 inch màn hình cong 3D",
        panel: "CrystalRes AMOLED 1.5K, 1800 nits, Dolby Vision",
        resolution: "1220 x 2712 Pixels",
        refreshRate: "120Hz mượt mà, cảm ứng 2160Hz"
      },
      performance: {
        chip: "MediaTek Dimensity 7200-Ultra (4nm)",
        ram: "8GB / 12GB",
        storage: "256GB / 512GB UFS 3.1"
      },
      camera: {
        main: "200MP Samsung ISOCELL HP3 f/1.65 OIS chống rung kép",
        ultraWide: "8MP góc rộng 120 độ",
        tele: "2MP Macro (Zoom cảm biến 2x/4x Lossless)",
        video: "4K 30fps, 1080p 120fps",
        features: "Xiaomi Imaging Engine, Chụp ảnh siêu chi tiết 200MP"
      },
      battery: {
        capacity: "5.000 mAh",
        charging: "120W HyperCharge siêu tốc (100% chỉ trong 19 phút)",
        wireless: "Không hỗ trợ"
      },
      osAndConnectivity: {
        os: "MIUI 14 / HyperOS (Android 14)",
        network: "5G kép",
        sim: "2 Nano SIM + eSIM",
        waterproof: "IP68 đầu tiên trên dòng Redmi Note"
      }
    }
  },

  "xiaomi poco x6 pro": {
    brand: "Xiaomi",
    variants: {
      storages: [
        { size: "256GB", offset: 0, default: true },
        { size: "512GB", offset: 1200000 }
      ],
      colors: [
        { name: "Vàng POCO", hex: "#ffcc00", img: "/images/products/poco_x6pro.jpg" },
        { name: "Đen", hex: "#1f1f1f", img: "/images/products/poco_x6pro.jpg" },
        { name: "Xám", hex: "#5c626e", img: "/images/products/poco_x6pro.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.67 inch CrystalRes Flow AMOLED",
        panel: "AMOLED 1.5K 68 tỷ màu, 1800 nits",
        resolution: "1220 x 2712 Pixels",
        refreshRate: "120Hz gaming, lấy mẫu cảm ứng tức thì 2160Hz"
      },
      performance: {
        chip: "Dimensity 8300-Ultra (4nm, Antutu hơn 1.4 triệu điểm)",
        ram: "8GB / 12GB LPDDR5X",
        storage: "256GB / 512GB UFS 4.0 siêu tốc"
      },
      camera: {
        main: "64MP f/1.7 OIS chống rung quang học",
        ultraWide: "8MP góc siêu rộng 120 độ",
        tele: "2MP macro",
        video: "4K 30fps, OIS + EIS",
        features: "Motion Tracking Focus chụp thể thao"
      },
      battery: {
        capacity: "5.000 mAh",
        charging: "67W sạc nhanh Turbo Charge (45 phút đầy)",
        wireless: "Không"
      },
      osAndConnectivity: {
        os: "Xiaomi HyperOS (Android 14)",
        network: "5G",
        sim: "2 Nano SIM",
        waterproof: "IP54 kháng nước nhẹ"
      }
    }
  },

  // === OPPO ===
  "oppo find x7 ultra": {
    brand: "OPPO",
    variants: {
      storages: [
        { size: "256GB", offset: 0, default: true },
        { size: "512GB", offset: 3000000 }
      ],
      colors: [
        { name: "Nâu Da Cổ Điển", hex: "#6e4732", img: "/images/products/oppo_findx7.jpg" },
        { name: "Đen Thạch Anh", hex: "#1f1f1f", img: "/images/products/oppo_findx7.jpg" },
        { name: "Xanh Hải Dương", hex: "#234952", img: "/images/products/oppo_findx7.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.82 inch cong LTPO AMOLED",
        panel: "QHD+ ProXDR 1 tỷ màu, 4500 nits cao nhất thế giới",
        resolution: "3168 x 1440 Pixels",
        refreshRate: "120Hz LTPO (1 - 120Hz)"
      },
      performance: {
        chip: "Snapdragon 8 Gen 3 (4nm)",
        ram: "16GB LPDDR5X",
        storage: "256GB / 512GB UFS 4.0"
      },
      camera: {
        main: "50MP 1-inch Sony LYT-900 OIS Hasselblad",
        ultraWide: "50MP Sony LYT-600 góc 123 độ",
        tele: "Camera Tele kép đầu tiên: 50MP 3x + 50MP 6x Kính tiềm vọng OIS",
        video: "4K 60fps Dolby Vision HDR toàn dải tiêu cự",
        features: "Hệ màu Hasselblad danh tiếng, Master Mode chân dung xóa phông tự nhiên"
      },
      battery: {
        capacity: "5.000 mAh",
        charging: "100W SUPERVOOC sạc đầy trong 26 phút",
        wireless: "50W sạc không dây AIRVOOC"
      },
      osAndConnectivity: {
        os: "ColorOS 14 (Android 14) mượt mà",
        network: "5G, Wi-Fi 7",
        sim: "2 Nano SIM vật lý",
        waterproof: "IP68 kháng nước bụi"
      }
    }
  },

  "oppo reno12 pro": {
    brand: "OPPO",
    variants: {
      storages: [
        { size: "256GB", offset: 0 },
        { size: "512GB", offset: 1800000, default: true }
      ],
      colors: [
        { name: "Bạc Vũ Trụ", hex: "#d8dde3", img: "/images/products/oppo_reno12.jpg" },
        { name: "Nâu Hoàng Hôn", hex: "#544439", img: "/images/products/oppo_reno12.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.7 inch cong nhẹ 4 cạnh Infinite View",
        panel: "AMOLED 1 tỷ màu, Gorilla Glass Victus 2",
        resolution: "1080 x 2412 Pixels (FHD+)",
        refreshRate: "120Hz siêu mượt"
      },
      performance: {
        chip: "MediaTek Dimensity 7300-Energy (4nm tiết kiệm pin)",
        ram: "12GB (+12GB RAM ảo)",
        storage: "512GB"
      },
      camera: {
        main: "50MP Sony LYT-600 OIS chống rung quang học",
        ultraWide: "8MP góc 112 độ",
        tele: "50MP Telephoto chân dung 2x zoom quang",
        video: "4K 30fps cả trước và sau",
        features: "Trọn bộ OPPO AI: Xóa vật thể AI, Tách nền AI, Làm nét khuôn mặt AI"
      },
      battery: {
        capacity: "5.000 mAh",
        charging: "80W SUPERVOOC (46 phút đầy)",
        wireless: "Không"
      },
      osAndConnectivity: {
        os: "ColorOS 14.1 tích hợp AI thế hệ mới",
        network: "5G",
        sim: "2 Nano SIM",
        waterproof: "IP65 kháng bụi nước và rơi vỡ chuẩn quân đội"
      }
    }
  },

  // === VIVO ===
  "vivo x100 pro": {
    brand: "Vivo",
    variants: {
      storages: [
        { size: "256GB", offset: 0, default: true },
        { size: "512GB", offset: 2800000 }
      ],
      colors: [
        { name: "Xanh Hoàng Hôn", hex: "#355964", img: "/images/products/vivo_x100pro.jpg" },
        { name: "Cam Sunset Leather", hex: "#e07831", img: "/images/products/vivo_x100pro.jpg" },
        { name: "Đen Sao Băng", hex: "#1e1e20", img: "/images/products/vivo_x100pro.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.78 inch cong 3D LTPO AMOLED",
        panel: "AMOLED 1.5K, 3000 nits, làm mờ PWM 2160Hz bảo vệ mắt",
        resolution: "1260 x 2800 Pixels",
        refreshRate: "120Hz LTPO thích ứng"
      },
      performance: {
        chip: "MediaTek Dimensity 9300 (4nm, toàn nhân lớn xung nhịp cực đại) + Chip hình ảnh V3",
        ram: "16GB LPDDR5T siêu nhanh",
        storage: "512GB UFS 4.0"
      },
      camera: {
        main: "50MP 1-inch Sony IMX989 f/1.75 OIS ZEISS",
        ultraWide: "50MP f/2.0 góc 119 độ",
        tele: "50MP ZEISS APO Floating Periscope Telephoto 4.3x quang (chụp mặt trời độc quyền)",
        video: "4K 60fps chân dung điện ảnh ZEISS Movie Mode",
        features: "Lớp phủ quang học ZEISS T* chống lóa chống bóng ma đỉnh cao"
      },
      battery: {
        capacity: "5.400 mAh công nghệ pin BlueOcean",
        charging: "100W FlashCharge (100% trong 29 phút)",
        wireless: "50W sạc không dây"
      },
      osAndConnectivity: {
        os: "Funtouch OS 14 / OriginOS 4 (Android 14)",
        network: "5G kép",
        sim: "2 Nano SIM",
        waterproof: "IP68 kháng nước kháng bụi chuẩn cao cấp"
      }
    }
  },

  "vivo y200e 5g": {
    brand: "Vivo",
    variants: {
      storages: [
        { size: "128GB", offset: 0, default: true },
        { size: "256GB", offset: 800000 }
      ],
      colors: [
        { name: "Cam Saffron Da Sinh Học", hex: "#d9783f", img: "/images/products/vivo_y200e.jpg" },
        { name: "Đen Pha Lê", hex: "#1e222a", img: "/images/products/vivo_y200e.jpg" }
      ]
    },
    specs: {
      screen: {
        size: "6.67 inch tràn viền",
        panel: "AMOLED FHD+, 1200 nits, loa kép stereo 300% âm lượng",
        resolution: "1080 x 2400 Pixels",
        refreshRate: "120Hz siêu mượt"
      },
      performance: {
        chip: "Snapdragon 4 Gen 2 (4nm 5G)",
        ram: "8GB (+8GB RAM ảo)",
        storage: "128GB / 256GB (thẻ nhớ MicroSD 1TB)"
      },
      camera: {
        main: "50MP f/1.8 chụp đêm rõ nét",
        ultraWide: "2MP Bokeh chân dung + Cảm biến Flicker",
        tele: "Không có",
        video: "1080p 30fps",
        features: "Đèn Aura Light độc quyền chụp chân dung tiệc đêm"
      },
      battery: {
        capacity: "5.000 mAh tuổi thọ bền bỉ 4 năm",
        charging: "44W FlashCharge sạc nhanh an toàn",
        wireless: "Không"
      },
      osAndConnectivity: {
        os: "Funtouch OS 14 (Android 14)",
        network: "5G tốc độ cao",
        sim: "2 SIM Nano",
        waterproof: "IP54 kháng nước văng và bụi bẩn"
      }
    }
  }
};

// === DANH MỤC TÌNH TRẠNG MÁY (CONDITIONS) TIÊU CHUẨN ===
const PHONE_CONDITIONS = [
  {
    id: "seal",
    name: "Mới 100% Nguyên Seal",
    shortName: "Mới Seal 100%",
    tag: "👑 Chính Hãng",
    desc: "Máy mới nguyên hộp, tự tay bóc seal, đầy đủ phụ kiện zin theo máy, bảo hành 12 tháng chính hãng.",
    factor: 1.0,
    warranty: "12 tháng chính hãng",
    gift: "Tặng củ sạc + cường lực cao cấp"
  },
  {
    id: "cpo",
    name: "Máy đổi bảo hành (CPO)",
    shortName: "Đổi Bảo Hành",
    tag: "🔄 Tiết kiệm",
    desc: "Máy mới 100% xuất kho trả bảo hành từ hãng, chưa kích hoạt hoặc kích hoạt trôi bảo hành, giá tốt hơn.",
    factor: 0.90, // Rẻ hơn 10%
    warranty: "12 tháng 1 đổi 1",
    gift: "Tặng bộ sạc nhanh 25W/30W + ốp lưng"
  },
  {
    id: "likenew",
    name: "Cũ 99% (Like New)",
    shortName: "Cũ 99% Like New",
    tag: "💎 Rẻ nhất",
    desc: "Máy hình thức đẹp như mới, không cấn móp, pin hoàn hảo 95-100%, nguyên bản chưa qua sửa chữa.",
    factor: 0.82, // Rẻ hơn 18%
    warranty: "6 tháng 1 đổi 1 trong 30 ngày",
    gift: "Tặng cáp sạc nhanh + dán màn hình trọn đời"
  }
];

// ==========================================================
// CƠ CHẾ ĐỒNG BỘ DỮ LIỆU BIẾN THỂ (ADMIN <-> CLIENT)
// ==========================================================
const CUSTOM_VARIANTS_STORAGE_KEY = 'PHONESTORE_CUSTOM_VARIANTS_DB';

function getCustomVariantsDB() {
  try {
    const raw = localStorage.getItem(CUSTOM_VARIANTS_STORAGE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch (e) {
    return {};
  }
}

function savePhoneCustomDetails(productIdOrName, details) {
  try {
    const db = getCustomVariantsDB();
    const key = String(productIdOrName).toLowerCase().trim();
    db[key] = details;
    localStorage.setItem(CUSTOM_VARIANTS_STORAGE_KEY, JSON.stringify(db));
    return true;
  } catch (e) {
    console.error('Lỗi lưu cấu hình biến thể:', e);
    return false;
  }
}

function extractVariantsFromDescription(desc) {
  if (!desc) return null;
  const match = desc.match(/<!--VARIANTS_JSON:([\s\S]*?)-->/);
  if (match && match[1]) {
    try {
      return JSON.parse(match[1]);
    } catch (e) {
      console.warn('Không thể parse VARIANTS_JSON từ mô tả:', e);
    }
  }
  return null;
}

function getCleanDescription(desc) {
  if (!desc) return '';
  return desc.replace(/<!--VARIANTS_JSON:[\s\S]*?-->/g, '').trim();
}

// Hàm tìm kiếm hoặc tự động sinh Specs & Variants cho mọi điện thoại
function getPhoneDetails(product) {
  if (!product) return null;
  const rawName = (product.name || "").toLowerCase().trim();
  const prodId = product.id ? String(product.id) : null;
  
  // 0. Ưu tiên 1: Dữ liệu biến thể lưu trực tiếp trong Database (description JSON)
  const fromDesc = extractVariantsFromDescription(product.description);
  if (fromDesc && fromDesc.variants) {
    return {
      brand: fromDesc.brand || product.categoryName || 'Smartphone',
      variants: fromDesc.variants,
      specs: fromDesc.specs || {},
      conditions: fromDesc.conditions || PHONE_CONDITIONS
    };
  }

  // 1. Ưu tiên 2: Dữ liệu biến thể tùy chỉnh do Admin lưu trong LocalStorage Cache
  const customDb = getCustomVariantsDB();
  if (prodId && customDb[prodId]) {
    return {
      ...customDb[prodId],
      conditions: customDb[prodId].conditions || PHONE_CONDITIONS
    };
  }
  if (customDb[rawName]) {
    return {
      ...customDb[rawName],
      conditions: customDb[rawName].conditions || PHONE_CONDITIONS
    };
  }

  // 2. Ưu tiên 3: Thử match chính xác theo bảng Specs DB PhoneStore
  for (const key of Object.keys(PHONE_SPECS_DB)) {
    if (rawName.includes(key)) {
      const data = PHONE_SPECS_DB[key];
      return {
        brand: data.brand,
        variants: data.variants,
        specs: data.specs,
        conditions: PHONE_CONDITIONS
      };
    }
  }

  // 3. Fallback thông minh dựa trên thương hiệu và mức giá của máy
  const isApple = rawName.includes("iphone") || (product.categoryName && product.categoryName.toLowerCase().includes("apple"));
  const isHighEnd = (product.price || 0) >= 15000000;
  const isMidRange = (product.price || 0) >= 6000000;

  const defaultStorages = isHighEnd
    ? [
        { size: "256GB", offset: 0, default: true },
        { size: "512GB", offset: 3000000 },
        { size: "1TB", offset: 7000000 }
      ]
    : isMidRange
    ? [
        { size: "128GB", offset: 0, default: true },
        { size: "256GB", offset: 1200000 }
      ]
    : [
        { size: "64GB", offset: -500000 },
        { size: "128GB", offset: 0, default: true }
      ];

  const defaultColors = isApple
    ? [
        { name: "Titan Tự Nhiên / Xám", hex: "#8f8b86", img: product.imageUrl },
        { name: "Đen Huyền Bí", hex: "#222224", img: product.imageUrl },
        { name: "Trắng Tinh Khôi", hex: "#f5f5f7", img: product.imageUrl },
        { name: "Xanh Navy", hex: "#344558", img: product.imageUrl }
      ]
    : [
        { name: "Đen Sang Trọng", hex: "#232325", img: product.imageUrl },
        { name: "Xanh Băng Tuyết", hex: "#94b9d8", img: product.imageUrl },
        { name: "Bạc Ánh Kim", hex: "#d8dce2", img: product.imageUrl }
      ];

  const fallbackSpecs = {
    screen: {
      size: isHighEnd ? "6.7 inch tràn viền" : "6.6 inch viền mỏng",
      panel: isHighEnd ? "Dynamic AMOLED 2X / Super Retina XDR" : isMidRange ? "Super AMOLED FHD+" : "IPS LCD 90Hz",
      resolution: isHighEnd ? "2K+ sắc nét rực rỡ" : "Full HD+ (1080 x 2400)",
      refreshRate: isHighEnd ? "120Hz thích ứng LTPO mượt mà" : isMidRange ? "120Hz mượt mà" : "90Hz lướt nhẹ"
    },
    performance: {
      chip: isApple ? "Apple Bionic / A-Series thế hệ mới" : isHighEnd ? "Snapdragon 8 Gen 3 / Dimensity 9300" : isMidRange ? "Snapdragon / Dimensity 5G tối ưu" : "Helio / Snapdragon đa nhân ổn định",
      ram: isHighEnd ? "12GB / 16GB đa nhiệm đỉnh cao" : isMidRange ? "8GB (+8GB RAM ảo)" : "4GB / 6GB",
      storage: isHighEnd ? "256GB / 512GB / 1TB UFS 4.0" : "128GB / 256GB"
    },
    camera: {
      main: isHighEnd ? "50MP - 200MP chống rung quang học OIS" : "50MP AI chụp đêm sắc nét",
      ultraWide: isHighEnd ? "12MP - 50MP góc siêu rộng 120 độ" : "8MP góc rộng",
      tele: isHighEnd ? "Telephoto Zoom quang học 3x - 5x bắt nét xa" : "Cảm biến đo độ sâu xóa phông",
      video: isHighEnd ? "4K 60fps / 8K chống rung OIS kép" : "Full HD 1080p 60fps",
      features: "Chụp đêm Night Mode, Xóa phông chân dung AI, HDR rực rỡ"
    },
    battery: {
      capacity: isHighEnd ? "4.500 - 5.400 mAh dùng cả ngày" : "5.000 mAh cực trâu",
      charging: isHighEnd ? "Sạc nhanh 45W - 100W siêu tốc" : isMidRange ? "Sạc nhanh 25W - 45W" : "Sạc tiêu chuẩn 15W - 18W",
      wireless: isHighEnd ? "Hỗ trợ sạc không dây tiện lợi" : "Không hỗ trợ"
    },
    osAndConnectivity: {
      os: isApple ? "iOS 17 chính hãng" : "Android 14 giao diện mới nhất",
      network: isHighEnd || isMidRange ? "5G đa băng tần tốc độ cực cao" : "4G LTE ổn định",
      sim: "2 SIM (Nano SIM vật lý hoặc eSIM)",
      waterproof: isHighEnd ? "IP68 kháng nước bụi tuyệt đối" : "IP54 kháng tia nước"
    }
  };

  return {
    brand: product.categoryName || (isApple ? "Apple" : "Smartphone"),
    variants: {
      storages: defaultStorages,
      colors: defaultColors
    },
    specs: fallbackSpecs,
    conditions: PHONE_CONDITIONS
  };
}

// Hàm tính toán giá cuối cùng theo tổ hợp biến thể
function calculatePhonePrice(basePrice, storageOffset, conditionFactor) {
  const priceWithStorage = basePrice + (storageOffset || 0);
  const finalPrice = Math.round((priceWithStorage * (conditionFactor || 1.0)) / 10000) * 10000;
  const originalPrice = Math.round((priceWithStorage * 1.15) / 10000) * 10000;
  const savedAmount = originalPrice - finalPrice;
  return {
    finalPrice,
    originalPrice,
    savedAmount
  };
}

// Phân loại nhóm màu sắc để khách hàng tìm kiếm & chọn lựa nhanh
function matchesColorGroup(product, targetGroup) {
  if (!targetGroup || targetGroup === 'all') return true;
  const details = getPhoneDetails(product);
  if (!details || !details.variants || !details.variants.colors) return true;

  const colorNames = details.variants.colors.map(c => c.name.toLowerCase()).join(' ');

  switch (targetGroup) {
    case 'titan':
      return colorNames.includes('titan') || colorNames.includes('xám') || colorNames.includes('gray') || colorNames.includes('metal');
    case 'black':
      return colorNames.includes('đen') || colorNames.includes('black') || colorNames.includes('midnight') || colorNames.includes('onyx') || colorNames.includes('bán dạ');
    case 'white':
      return colorNames.includes('trắng') || colorNames.includes('white') || colorNames.includes('bạc') || colorNames.includes('silver') || colorNames.includes('starlight') || colorNames.includes('gốm');
    case 'blue':
      return colorNames.includes('xanh') || colorNames.includes('blue') || colorNames.includes('navy') || colorNames.includes('iceblue') || colorNames.includes('hải dương');
    case 'gold':
      return colorNames.includes('vàng') || colorNames.includes('gold') || colorNames.includes('amber') || colorNames.includes('saffron');
    case 'pink_purple':
      return colorNames.includes('hồng') || colorNames.includes('tím') || colorNames.includes('pink') || colorNames.includes('purple') || colorNames.includes('lilac') || colorNames.includes('rose') || colorNames.includes('aurora');
    default:
      return true;
  }
}
