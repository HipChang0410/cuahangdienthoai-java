package com.example.demo.service;

import com.example.demo.dto.ProductDTO;

import java.util.List;

public interface ProductService {

    ProductDTO create(ProductDTO productDTO);

    List<ProductDTO> getAllProducts();

    ProductDTO getProductById(Long id);

    ProductDTO update(Long id, ProductDTO productDTO);

    void delete(Long id);

    List<ProductDTO> searchByName(String name);

    List<ProductDTO> searchByCategory(Long categoryId);

    List<ProductDTO> searchByCategoryName(String categoryName);
}
