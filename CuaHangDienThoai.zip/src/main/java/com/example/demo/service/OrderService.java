package com.example.demo.service;

import com.example.demo.dto.OrderRequestDTO;
import com.example.demo.dto.OrderResponseDTO;
import com.example.demo.entity.Order;

import java.util.List;

public interface OrderService {
    Order placeOrder(OrderRequestDTO request);
    List<OrderResponseDTO> getOrdersByUser(Long userId);
    OrderResponseDTO getOrderById(Long id);
    OrderResponseDTO updateStatus(Long id, String status);
    List<OrderResponseDTO> getAllOrders();
}
