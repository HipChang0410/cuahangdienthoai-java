package com.example.demo.service;

import com.example.demo.dto.OrderRequestDTO;
import com.example.demo.dto.OrderResponseDTO;
import com.example.demo.entity.Order;
import com.example.demo.entity.OrderDetail;
import com.example.demo.entity.Product;
import com.example.demo.entity.User;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.OrderDetailRepository;
import com.example.demo.repository.OrderRepository;
import com.example.demo.repository.ProductRepository;
import com.example.demo.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepository;
    private final OrderDetailRepository orderDetailRepository;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;

    public OrderServiceImpl(OrderRepository orderRepository, OrderDetailRepository orderDetailRepository,
                            ProductRepository productRepository, UserRepository userRepository) {
        this.orderRepository = orderRepository;
        this.orderDetailRepository = orderDetailRepository;
        this.productRepository = productRepository;
        this.userRepository = userRepository;
    }

    @Override
    @Transactional
    public Order placeOrder(OrderRequestDTO request) {
        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Order order = new Order();
        order.setUser(user);
        order.setOrderDate(LocalDateTime.now());
        order.setStatus("PENDING");
        order.setShippingAddress(request.getShippingAddress());
        
        order = orderRepository.save(order);

        double totalAmount = 0.0;
        List<OrderDetail> details = new ArrayList<>();

        for (OrderRequestDTO.OrderItemDTO item : request.getItems()) {
            Product product = productRepository.findById(item.getProductId())
                    .orElseThrow(() -> new ResourceNotFoundException("Product not found: " + item.getProductId()));
            
            if (product.getQuantity() < item.getQuantity()) {
                throw new RuntimeException("Sản phẩm '" + product.getName() + "' không đủ số lượng trong kho!");
            }

            // Trừ tồn kho
            product.setQuantity(product.getQuantity() - item.getQuantity());
            productRepository.save(product);

            OrderDetail detail = new OrderDetail();
            detail.setOrder(order);
            detail.setProduct(product);
            detail.setQuantity(item.getQuantity());
            detail.setUnitPrice(product.getPrice());
            
            details.add(detail);
            totalAmount += (product.getPrice() * item.getQuantity());
        }

        orderDetailRepository.saveAll(details);
        
        order.setTotalAmount(totalAmount);
        return orderRepository.save(order);
    }

    @Override
    public List<OrderResponseDTO> getOrdersByUser(Long userId) {
        List<Order> orders = orderRepository.findByUserId(userId);
        return orders.stream().map(this::toResponseDTO).collect(Collectors.toList());
    }

    @Override
    public OrderResponseDTO getOrderById(Long id) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy đơn hàng id = " + id));
        return toResponseDTO(order);
    }

    @Override
    public OrderResponseDTO updateStatus(Long id, String status) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy đơn hàng id = " + id));
        boolean wasCancelled = "CANCELLED".equals(order.getStatus());
        boolean nowCancelled = "CANCELLED".equals(status);
        if (wasCancelled != nowCancelled) {
            // Hủy đơn -> hoàn kho; khôi phục đơn đã hủy -> trừ kho lại
            int sign = nowCancelled ? 1 : -1;
            for (OrderDetail d : orderDetailRepository.findByOrderId(order.getId())) {
                Product p = d.getProduct();
                int newQty = p.getQuantity() + sign * d.getQuantity();
                if (newQty < 0) {
                    throw new RuntimeException("Sản phẩm '" + p.getName() + "' không đủ số lượng trong kho!");
                }
                p.setQuantity(newQty);
                productRepository.save(p);
            }
        }
        order.setStatus(status);
        return toResponseDTO(orderRepository.save(order));
    }

    @Override
    public List<OrderResponseDTO> getAllOrders() {
        return orderRepository.findAll().stream()
                .map(this::toResponseDTO)
                .collect(Collectors.toList());
    }

    private OrderResponseDTO toResponseDTO(Order order) {
        OrderResponseDTO dto = new OrderResponseDTO();
        dto.setId(order.getId());
        dto.setUserId(order.getUser().getId());
        dto.setUserFullName(order.getUser().getFullName());
        dto.setOrderDate(order.getOrderDate());
        dto.setTotalAmount(order.getTotalAmount());
        dto.setStatus(order.getStatus());
        dto.setShippingAddress(order.getShippingAddress());

        List<OrderDetail> details = orderDetailRepository.findByOrderId(order.getId());
        List<OrderResponseDTO.OrderItemResponseDTO> items = details.stream().map(d -> {
            OrderResponseDTO.OrderItemResponseDTO item = new OrderResponseDTO.OrderItemResponseDTO();
            item.setProductId(d.getProduct().getId());
            item.setProductName(d.getProduct().getName());
            item.setImageUrl(d.getProduct().getImageUrl());
            item.setQuantity(d.getQuantity());
            item.setUnitPrice(d.getUnitPrice());
            return item;
        }).collect(Collectors.toList());

        dto.setItems(items);
        return dto;
    }
}
