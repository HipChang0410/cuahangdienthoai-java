package com.example.demo.service;

import com.example.demo.dto.CategoryDTO;

import java.util.List;

public interface CategoryService {

    CategoryDTO create(CategoryDTO categoryDTO);

    List<CategoryDTO> getAllCategories();

    CategoryDTO getCategoryById(Long id);

    CategoryDTO update(Long id, CategoryDTO categoryDTO);

    void delete(Long id);
}
