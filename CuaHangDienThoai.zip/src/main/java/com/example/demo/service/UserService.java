package com.example.demo.service;

import com.example.demo.dto.RegisterDTO;
import com.example.demo.dto.UserDTO;

import java.util.List;

public interface UserService {
    UserDTO register(RegisterDTO registerDTO);
    UserDTO findByUsername(String username);
    UserDTO findById(Long id);
    UserDTO update(Long id, UserDTO userDTO);
    List<UserDTO> getAllUsers();
}
