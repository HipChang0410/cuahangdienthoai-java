package com.example.demo.config;

import com.example.demo.entity.Category;
import com.example.demo.entity.Product;
import com.example.demo.entity.User;
import com.example.demo.repository.CategoryRepository;
import com.example.demo.repository.ProductRepository;
import com.example.demo.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
@Profile("!test")
public class DataInitializer implements CommandLineRunner {

    private final CategoryRepository categoryRepository;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;

    public DataInitializer(CategoryRepository categoryRepository,
                           ProductRepository productRepository,
                           UserRepository userRepository) {
        this.categoryRepository = categoryRepository;
        this.productRepository = productRepository;
        this.userRepository = userRepository;
    }

    private static final Map<String, String> IMAGES = Map.ofEntries(
            Map.entry("Samsung Galaxy S24 Ultra", "/images/products/s24_ultra.jpg"),
            Map.entry("Samsung Galaxy S24+", "/images/products/s24_plus.jpg"),
            Map.entry("Samsung Galaxy A55 5G", "/images/products/galaxy_a55.jpg"),
            Map.entry("Samsung Galaxy Z Fold6", "/images/products/z_fold6.jpg"),
            Map.entry("iPhone 15 Pro Max", "/images/products/iphone15_promax.jpg"),
            Map.entry("iPhone 15 Pro", "/images/products/iphone15_pro.jpg"),
            Map.entry("iPhone 15", "/images/products/iphone15.jpg"),
            Map.entry("iPhone 14", "/images/products/iphone14.jpg"),
            Map.entry("Xiaomi 14 Ultra", "/images/products/xiaomi14_ultra.jpg"),
            Map.entry("Redmi Note 13 Pro+", "/images/products/redmi_note13.jpg"),
            Map.entry("Xiaomi Poco X6 Pro", "/images/products/poco_x6pro.jpg"),
            Map.entry("OPPO Find X7 Ultra", "/images/products/oppo_findx7.jpg"),
            Map.entry("OPPO Reno12 Pro", "/images/products/oppo_reno12.jpg"),
            Map.entry("Vivo X100 Pro", "/images/products/vivo_x100pro.jpg"),
            Map.entry("Vivo Y200e 5G", "/images/products/vivo_y200e.jpg")
    );

    @Override
    public void run(String... args) {
        // Cap nhat anh noi bo cho san pham da ton tai (anh cu tu CDN bi chan)
        productRepository.findAll().forEach(p -> {
            String img = IMAGES.get(p.getName());
            if (img != null && (p.getImageUrl() == null || !p.getImageUrl().equals(img))) {
                p.setImageUrl(img);
                productRepository.save(p);
            }
        });
        addMissingBudgetProducts();
        addMissingIphoneAndFlagshipProducts();

        // Chỉ seed khi chưa có dữ liệu
        if (categoryRepository.count() > 0) return;

        // === TẠO CATEGORIES ===
        Category samsung = new Category(null, "Samsung", "Điện thoại thương hiệu Samsung");
        Category apple = new Category(null, "Apple", "iPhone - Điện thoại thương hiệu Apple");
        Category xiaomi = new Category(null, "Xiaomi", "Điện thoại thương hiệu Xiaomi");
        Category oppo = new Category(null, "OPPO", "Điện thoại thương hiệu OPPO");
        Category vivo = new Category(null, "Vivo", "Điện thoại thương hiệu Vivo");

        samsung = categoryRepository.save(samsung);
        apple = categoryRepository.save(apple);
        xiaomi = categoryRepository.save(xiaomi);
        oppo = categoryRepository.save(oppo);
        vivo = categoryRepository.save(vivo);

        // === TẠO PRODUCTS - SAMSUNG ===
        productRepository.save(new Product(null, "Samsung Galaxy S24 Ultra",
                31990000.0, 50,
                "/images/products/s24_ultra.jpg",
                "Samsung Galaxy S24 Ultra với camera 200MP, màn hình Dynamic AMOLED 2X 6.8 inch, chip Snapdragon 8 Gen 3 mạnh mẽ. RAM 12GB, bộ nhớ 256GB.",
                samsung));

        productRepository.save(new Product(null, "Samsung Galaxy S24+",
                22990000.0, 45,
                "/images/products/s24_plus.jpg",
                "Samsung Galaxy S24+ màn hình Dynamic AMOLED 2X 6.7 inch, chip Snapdragon 8 Gen 3, camera 50MP, RAM 12GB.",
                samsung));

        productRepository.save(new Product(null, "Samsung Galaxy A55 5G",
                10490000.0, 80,
                "/images/products/galaxy_a55.jpg",
                "Samsung Galaxy A55 5G màn hình Super AMOLED 6.6 inch, chip Exynos 1480, camera 50MP, RAM 8GB, pin 5000mAh.",
                samsung));

        productRepository.save(new Product(null, "Samsung Galaxy Z Fold6",
                47990000.0, 20,
                "/images/products/z_fold6.jpg",
                "Samsung Galaxy Z Fold6 màn hình gập 7.6 inch, chip Snapdragon 8 Gen 3, camera 50MP, RAM 12GB, bộ nhớ 256GB.",
                samsung));

        // === TẠO PRODUCTS - APPLE ===
        productRepository.save(new Product(null, "iPhone 15 Pro Max",
                34990000.0, 35,
                "/images/products/iphone15_promax.jpg",
                "iPhone 15 Pro Max với chip A17 Pro, màn hình Super Retina XDR 6.7 inch, hệ thống camera 48MP chuyên nghiệp, cổng USB-C.",
                apple));

        productRepository.save(new Product(null, "iPhone 15 Pro",
                28990000.0, 40,
                "/images/products/iphone15_pro.jpg",
                "iPhone 15 Pro chip A17 Pro, màn hình 6.1 inch, camera 48MP, thiết kế titan siêu bền với cổng USB-C.",
                apple));

        productRepository.save(new Product(null, "iPhone 15",
                22990000.0, 60,
                "/images/products/iphone15.jpg",
                "iPhone 15 chip A16 Bionic, màn hình Super Retina XDR 6.1 inch, camera 48MP, Dynamic Island, cổng USB-C.",
                apple));

        productRepository.save(new Product(null, "iPhone 14",
                17990000.0, 55,
                "/images/products/iphone14.jpg",
                "iPhone 14 chip A15 Bionic, màn hình 6.1 inch, camera kép 12MP, pin 3279mAh, iOS 17.",
                apple));

        // === TẠO PRODUCTS - XIAOMI ===
        productRepository.save(new Product(null, "Xiaomi 14 Ultra",
                24990000.0, 30,
                "/images/products/xiaomi14_ultra.jpg",
                "Xiaomi 14 Ultra chip Snapdragon 8 Gen 3, camera Leica 50MP, màn hình AMOLED 6.73 inch, RAM 16GB, sạc 90W.",
                xiaomi));

        productRepository.save(new Product(null, "Redmi Note 13 Pro+",
                9990000.0, 70,
                "/images/products/redmi_note13.jpg",
                "Redmi Note 13 Pro+ chip Dimensity 7200 Ultra, camera 200MP, màn hình AMOLED 6.67 inch, sạc nhanh 120W.",
                xiaomi));

        productRepository.save(new Product(null, "Xiaomi Poco X6 Pro",
                8490000.0, 65,
                "/images/products/poco_x6pro.jpg",
                "Xiaomi POCO X6 Pro chip Dimensity 8300 Ultra, màn hình AMOLED 6.67 inch 144Hz, camera 64MP, RAM 12GB.",
                xiaomi));

        // === TẠO PRODUCTS - OPPO ===
        productRepository.save(new Product(null, "OPPO Find X7 Ultra",
                26990000.0, 25,
                "/images/products/oppo_findx7.jpg",
                "OPPO Find X7 Ultra chip Snapdragon 8 Gen 3, camera Hasselblad 50MP, màn hình AMOLED 6.82 inch, sạc 100W.",
                oppo));

        productRepository.save(new Product(null, "OPPO Reno12 Pro",
                12990000.0, 55,
                "/images/products/oppo_reno12.jpg",
                "OPPO Reno12 Pro chip Dimensity 9200+, camera 50MP, màn hình AMOLED 6.7 inch, RAM 12GB, sạc 80W.",
                oppo));

        // === TẠO PRODUCTS - VIVO ===
        productRepository.save(new Product(null, "Vivo X100 Pro",
                25990000.0, 28,
                "/images/products/vivo_x100pro.jpg",
                "Vivo X100 Pro chip Dimensity 9300, camera Zeiss 50MP, màn hình AMOLED 6.78 inch, pin 5400mAh, sạc 100W.",
                vivo));

        productRepository.save(new Product(null, "Vivo Y200e 5G",
                5990000.0, 90,
                "/images/products/vivo_y200e.jpg",
                "Vivo Y200e 5G chip Snapdragon 4 Gen 1, camera 64MP, màn hình AMOLED 6.78 inch, pin 5000mAh, sạc 44W.",
                vivo));

        // === TẠO ADMIN USER ===
        if (!userRepository.existsByUsername("admin")) {
            User admin = new User();
            admin.setUsername("admin");
            admin.setPassword("admin123");
            admin.setFullName("Quản trị viên");
            admin.setEmail("admin@phonestore.vn");
            admin.setPhone("0901234567");
            admin.setAddress("123 Đường Nguyễn Huệ, Q1, TP.HCM");
            admin.setRole("ROLE_ADMIN");
            userRepository.save(admin);
        }

        // === TẠO USER MẪU ===
        if (!userRepository.existsByUsername("user1")) {
            User user1 = new User();
            user1.setUsername("user1");
            user1.setPassword("user123");
            user1.setFullName("Nguyễn Văn An");
            user1.setEmail("nguyenvanan@gmail.com");
            user1.setPhone("0912345678");
            user1.setAddress("456 Lê Lợi, Q1, TP.HCM");
            user1.setRole("ROLE_USER");
            userRepository.save(user1);
        }

        System.out.println("✅ Data seeded successfully! 16 sản phẩm & 2 users đã được tạo.");
    }

    // Bo sung cac san pham gia duoi 5 trieu (chay ca khi DB da co du lieu)
    private void addMissingBudgetProducts() {
        java.util.Set<String> existing = new java.util.HashSet<>();
        productRepository.findAll().forEach(p -> existing.add(p.getName()));
        java.util.Map<String, Category> cats = new java.util.HashMap<>();
        categoryRepository.findAll().forEach(c -> cats.put(c.getName(), c));
        if (cats.isEmpty()) return;

        Object[][] data = {
            {"Samsung Galaxy A05s", 3490000.0, 120, "galaxy_a05s.jpg", "Samsung",
             "Samsung Galaxy A05s màn hình PLS LCD 6.7 inch 90Hz, chip Snapdragon 680, camera 50MP, RAM 4GB, pin 5000mAh. Lựa chọn tuyệt vời trong tầm giá."},
            {"Samsung Galaxy A15", 4690000.0, 100, "galaxy_a15.jpg", "Samsung",
             "Samsung Galaxy A15 màn hình Super AMOLED 6.5 inch 90Hz, chip Helio G99, camera 50MP, RAM 6GB, pin 5000mAh, sạc nhanh 25W."},
            {"Redmi 13C", 2990000.0, 150, "redmi_13c.jpg", "Xiaomi",
             "Xiaomi Redmi 13C màn hình 6.74 inch 90Hz, chip Helio G85, camera 50MP, RAM 4GB, pin 5000mAh. Giá rẻ, hiệu năng ổn định."},
            {"Redmi A3", 2290000.0, 140, "redmi_a3.jpg", "Xiaomi",
             "Xiaomi Redmi A3 màn hình 6.71 inch 90Hz, chip Helio G36, camera 8MP, RAM 3GB, pin 5000mAh. Điện thoại phổ thông siêu tiết kiệm."},
            {"OPPO A18", 3990000.0, 90, "oppo_a18.jpg", "OPPO",
             "OPPO A18 màn hình 6.56 inch 90Hz, chip Helio G85, camera 8MP, RAM 4GB, pin 5000mAh, thiết kế vân sáng bắt mắt."},
            {"Vivo Y17s", 3790000.0, 95, "vivo_y17s.jpg", "Vivo",
             "Vivo Y17s màn hình 6.56 inch 90Hz, chip Helio G85, camera 50MP, RAM 4GB, pin 5000mAh, thiết kế mỏng nhẹ."}
        };
        for (Object[] d : data) {
            String name = (String) d[0];
            Category cat = cats.get((String) d[4]);
            if (existing.contains(name) || cat == null) continue;
            productRepository.save(new Product(null, name, (Double) d[1], (Integer) d[2],
                    "/images/products/" + d[3], (String) d[5], cat));
        }
    }

    // Bo sung cac dong iPhone tu 11 toi 18 va cac san pham moi
    private void addMissingIphoneAndFlagshipProducts() {
        java.util.Set<String> existing = new java.util.HashSet<>();
        productRepository.findAll().forEach(p -> existing.add(p.getName()));
        java.util.Map<String, Category> cats = new java.util.HashMap<>();
        categoryRepository.findAll().forEach(c -> cats.put(c.getName(), c));
        if (cats.isEmpty()) return;

        Category apple = cats.get("Apple");
        Category samsung = cats.get("Samsung");
        Category xiaomi = cats.get("Xiaomi");
        Category oppo = cats.get("OPPO");

        Object[][] items = {
            // iPhone 11 -> 18
            {"iPhone 11", 8490000.0, 120, "iphone11.jpg", apple, "iPhone 11 với chip A13 Bionic, camera kép 12MP góc rộng và siêu rộng, màn hình Liquid Retina 6.1 inch, pin bền bỉ."},
            {"iPhone 11 Pro Max", 10990000.0, 85, "iphone11_promax.jpg", apple, "iPhone 11 Pro Max màn hình Super Retina XDR 6.5 inch, cụm 3 camera 12MP chụp đêm ấn tượng, khung thép không gỉ."},
            {"iPhone 12", 11490000.0, 90, "iphone12.jpg", apple, "iPhone 12 thiết kế cạnh vuông hiện đại, chip A14 Bionic mạnh mẽ, màn hình OLED Super Retina XDR 6.1 inch, kết nối 5G siêu tốc."},
            {"iPhone 12 Pro Max", 14990000.0, 70, "iphone12_promax.jpg", apple, "iPhone 12 Pro Max với màn hình lớn 6.7 inch, cảm biến LiDAR, zoom quang học sắc nét, chip A14 Bionic."},
            {"iPhone 13", 13990000.0, 110, "iphone13.jpg", apple, "iPhone 13 cụm camera chéo độc đáo, tính năng quay phim Cinematic Mode, thời lượng pin tăng vượt trội cùng chip A15 Bionic."},
            {"iPhone 13 Pro Max", 17990000.0, 65, "iphone13_promax.jpg", apple, "iPhone 13 Pro Max màn hình 120Hz ProMotion siêu mượt, cụm 3 camera chuyên nghiệp góc macro, pin cực trâu."},
            {"iPhone 14 Plus", 18990000.0, 60, "iphone14_plus.jpg", apple, "iPhone 14 Plus màn hình lớn 6.7 inch, pin cực khủng, tính năng phát hiện va chạm khẩn cấp và chip A15 nâng cấp."},
            {"iPhone 14 Pro", 22990000.0, 50, "iphone14_pro.jpg", apple, "iPhone 14 Pro tiên phong với Dynamic Island, camera chính 48MP sắc nét, màn hình Always-On Display và chip A16 Bionic."},
            {"iPhone 14 Pro Max", 25490000.0, 60, "iphone14_promax.jpg", apple, "iPhone 14 Pro Max màn hình lớn 6.7 inch 120Hz, Dynamic Island thông minh, chip A16 Bionic đỉnh cao cùng vỏ thép cao cấp."},
            {"iPhone 15 Plus", 22990000.0, 45, "iphone15_plus.jpg", apple, "iPhone 15 Plus màn hình 6.7 inch rực rỡ, Dynamic Island, cổng sạc USB-C tiện lợi, camera 48MP và pin bền bỉ."},
            {"iPhone 16", 22490000.0, 80, "iphone16.jpg", apple, "iPhone 16 trang bị chip Apple A18 cực mạnh, nút Camera Control tiện dụng, camera kép đặt dọc hỗ trợ quay Spatial Video, Apple Intelligence."},
            {"iPhone 16 Plus", 25990000.0, 50, "iphone16_plus.jpg", apple, "iPhone 16 Plus màn hình 6.7 inch, chip A18 3nm, nút điều khiển camera mới, thời lượng pin vượt bậc."},
            {"iPhone 16 Pro", 28990000.0, 60, "iphone16_pro.jpg", apple, "iPhone 16 Pro khung Titan Grade 5 siêu nhẹ, màn hình viền mỏng 6.3 inch 120Hz, chip A18 Pro hỗ trợ AI thế hệ mới, camera tele 5x Tetraprism."},
            {"iPhone 16 Pro Max", 34990000.0, 75, "iphone16_promax.jpg", apple, "iPhone 16 Pro Max đỉnh cao công nghệ: màn hình 6.9 inch lớn nhất, chip Apple A18 Pro, pin kỷ lục, quay 4K 120fps Dolby Vision."},
            {"iPhone 17 Pro", 33490000.0, 30, "iphone17_pro.jpg", apple, "iPhone 17 Pro thế hệ đột phá với chip Apple A19 Pro, Face ID dưới màn hình, camera zoom tiềm vọng 10x, hệ thống tản nhiệt buồng hơi."},
            {"iPhone 17 Pro Max", 39490000.0, 35, "iphone17_promax.jpg", apple, "iPhone 17 Pro Max màn hình chống chói Nano-texture 6.9 inch, chip Apple A19 Pro, RAM 12GB tích hợp AI toàn diện."},
            {"iPhone 18 Pro", 37990000.0, 25, "iphone18_pro.jpg", apple, "iPhone 18 Pro thiết kế nguyên khối Titanium, chip Apple A20 Bionic tốc độ lượng tử, camera khẩu độ biến thiên tự động."},
            {"iPhone 18 Pro Max", 45990000.0, 20, "iphone18_promax.jpg", apple, "iPhone 18 Pro Max đỉnh cao tương lai: màn hình tràn viền 100%, chip A20 2nm lượng tử, cảm biến ảnh 1 inch chuyên nghiệp."},
            // Flagships moi cua Samsung, Xiaomi, OPPO
            {"Samsung Galaxy Z Flip6", 24990000.0, 40, "z_flip6.jpg", samsung, "Samsung Galaxy Z Flip6 thiết kế gập vỏ sò thời thượng, FlexWindow 3.4 inch, Snapdragon 8 Gen 3 for Galaxy, Galaxy AI."},
            {"Samsung Galaxy S23 Ultra", 19990000.0, 50, "s23_ultra.jpg", samsung, "Samsung Galaxy S23 Ultra camera 200MP zoom 100x sắc nét, bút S-Pen quyền lực, Snapdragon 8 Gen 2 mượt mà."},
            {"Xiaomi 14", 18490000.0, 45, "xiaomi14.jpg", xiaomi, "Xiaomi 14 ống kính quang học Leica Summilux, Snapdragon 8 Gen 3, màn hình 6.36 inch viền siêu mỏng, sạc 90W."},
            {"OPPO Reno11 5G", 8990000.0, 70, "oppo_reno11.jpg", oppo, "OPPO Reno11 5G mặt lưng vân sóng tinh tế, chuyên gia chân dung 32MP, pin 5000mAh, sạc nhanh SUPERVOOC 67W."}
        };

        for (Object[] item : items) {
            String name = (String) item[0];
            Category cat = (Category) item[4];
            if (existing.contains(name) || cat == null) continue;
            productRepository.save(new Product(null, name, (Double) item[1], (Integer) item[2],
                    "/images/products/" + item[3], (String) item[5], cat));
        }
    }
}