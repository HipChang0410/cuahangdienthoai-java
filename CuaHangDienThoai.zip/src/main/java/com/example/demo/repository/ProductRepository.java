package com.example.demo.repository;

import com.example.demo.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long> {

    // Tìm sản phẩm theo tên (không phân biệt hoa/thường), sắp xếp theo ID tăng dần
    List<Product> findByNameContainingIgnoreCaseOrderByIdAsc(String name);

    // Tìm sản phẩm theo khoảng giá, sắp xếp theo giá tăng dần rồi theo ID tăng dần
    List<Product> findByPriceBetweenOrderByPriceAscIdAsc(Double minPrice, Double maxPrice);

    // Tìm sản phẩm có số lượng >= giá trị cho trước, sắp xếp theo số lượng giảm dần rồi theo ID tăng dần
    List<Product> findByQuantityGreaterThanEqualOrderByQuantityDescIdAsc(Integer quantity);

    // Tìm kiếm nâng cao: theo tên category, khoảng giá, và số lượng tối thiểu
    @Query("SELECT p FROM Product p JOIN p.category c " +
           "WHERE LOWER(c.name) LIKE LOWER(CONCAT('%', :categoryName, '%')) " +
           "AND p.price BETWEEN :minPrice AND :maxPrice " +
           "AND p.quantity >= :minQuantity " +
           "ORDER BY p.id ASC")
    List<Product> searchByCategoryAndPriceAndQuantity(
            @Param("categoryName") String categoryName,
            @Param("minPrice") Double minPrice,
            @Param("maxPrice") Double maxPrice,
            @Param("minQuantity") Integer minQuantity
    );
}
