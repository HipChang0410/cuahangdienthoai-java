# Cua hang dien thoai - Do an Lap trinh Java

Do an website cua hang dien thoai dung Java 21, Spring Boot 3.3.4, Spring Data JPA, Gradle va MySQL.

## Cai dat va chay

1. Cai JDK 21 va MySQL; khoi dong MySQL.
2. Cau hinh `src/main/resources/application.properties` hoac `application-mysql.properties` cho tai khoan MySQL cua may ban (khong commit mat khau that).
3. Tu thu muc goc du an, chay `gradlew.bat bootRun` (Windows) hoac `./gradlew bootRun` (Linux/macOS).
4. Truy cap `http://localhost:8080` (neu khong thay doi cong).
5. Chay kiem thu bang `gradlew.bat test` (Windows).

## Cau truc

- `src/main/java`: controllers, entities, repositories va logic ung dung.
- `src/main/resources/static`: tai nguyen web, hinh anh da toi uu dung luong.
- `src/main/resources/application*.properties`: cau hinh ket noi CSDL.
- `src/test`: test Spring Boot su dung H2.
- `gradle/wrapper`, `gradlew*`, `build.gradle`: cong cu build.

## Luu y

- Khong dua file `.gradle/`, `build/`, `bin/`, `*.log` hay database chay cuc bo len GitHub.
- Mat khau MySQL tren moi may phai duoc cau hinh rieng.
- Ma nguon la do an hoc tap; can danh gia bao mat truoc khi su dung cong khai.
